# Aspen Harness — Agent Rules

Applies to any coding agent (Claude Code, Copilot, others) working from this folder.

## Layout
- `repos/app` — Angular web app. Real AzDO clone; feature code is written here directly.
- `repos/api` — .NET API. Real AzDO clone.
- Everything else is the harness (local-only, versioned in its own git repo). It never reaches upstream.

## Commands (`pwsh ./harness.ps1 <cmd>`)
`up` · `sync` · `status` · `doctor` · `new-feature <repo> <name>` · `ship <repo> -m "msg" [-All]` ·
`clean-check <repo>` · `overlay apply|remove|status` · `patch apply|reset|status|new|refresh|retire` · `hooks install|status|uninstall` ·
`secrets apply|status <repo>` · `discover <repo> [-Path <clone>] [-Out <md>]`

## Hard rules
1. Never commit or push harness-managed paths in `repos/*`: patch targets (`patches/<repo>/manifest.json` → `targets`) and overlay paths (`overlay/<repo>/**`). Hooks enforce this; do not bypass (`--no-verify`, `HARNESS_ALLOW_PATCHED=1`) unless the user explicitly says so for a genuine upstream change.
2. Local-environment needs go in the lowest tier that works:
   - Tier 1: env vars / CLI args in `aspen.code-workspace`, `config/`
   - Tier 2: harness-root `Directory.Build.props`, `.editorconfig`, `nuget.config` (npm ignores parent `.npmrc`: use `~/.npmrc`/`NPM_CONFIG_*`)
   - Tier 3: new local-only files → `overlay/<repo>/…`
   - Tier 4: edits to tracked upstream files → `patch new` (never hand-maintain edits in a clone)
3. Never edit a patched file for local needs directly in a clone and leave it; capture with `patch new` / `patch refresh`.
4. Feature changes must work without the harness: run `clean-check <repo>` before suggesting a PR.
5. Don't modify upstream code to accommodate the local env. If upstream lacks an extension point, propose it as a separate team PR (see docs/aspen-harness-plan.md Phase 10).
6. Ship via `./harness.ps1 ship` (resets patches, commits, pushes, re-applies). Never push the harness repo anywhere.
7. Ask before any destructive or upstream-visible git operation (push, force-push, branch delete, rebase of pushed commits).
8. Never read or print `config/*.secrets.local.json`; refer to keys only (`secrets status` masks values).
9. Never change `core.hooksPath` or files under `repos/*/.git/` by hand; use `hooks install|uninstall`.
