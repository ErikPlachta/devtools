# Guard hooks (local, never pushed). Each hook is a thin POSIX sh shim that chains to
# the hook it displaced, then runs hooks/guard.ps1.
#
# Two install modes:
#   default  : core.hooksPath unset -> shims in .git/hooks; existing hooks kept as <name>.chained
#   takeover : core.hooksPath set (husky etc.) -> LOCAL core.hooksPath is pointed at
#              .git/harness/hooks; shims chain to <original hooksPath>/<name>. Nothing tracked changes.
#              Original value recorded in .git/harness/hooks.json; 'hooks uninstall' restores it.

$script:HookMarker = '# aspen-harness-hook v1'
$script:HookNames = @('pre-commit', 'post-commit', 'pre-push', 'post-checkout', 'post-merge')

function ConvertTo-PosixPath([string]$Path) { $Path -replace '\\', '/' }

function Get-HookStatePath([string]$Repo) { Join-Path (Get-RepoStateDir $Repo) 'hooks.json' }

function Get-TakeoverHooksDir([string]$Repo) { ConvertTo-PosixPath (Join-Path (Get-RepoStateDir $Repo) 'hooks') }

function Get-ConfiguredHooksPath([string]$Repo) {
    $p = (Get-RepoInfo $Repo).Path
    (Invoke-Git $p @('config', '--get', 'core.hooksPath') -AllowFail) | Select-Object -First 1
}

# Resolve where hooks go and what each shim chains to. Read-only.
function Get-HookPlan([string]$Repo) {
    $info = Get-RepoInfo $Repo
    $state = Read-JsonFile (Get-HookStatePath $Repo) @{}
    $current = Get-ConfiguredHooksPath $Repo
    $ours = Get-TakeoverHooksDir $Repo
    if (-not $current) {
        return [pscustomobject]@{ Mode = 'default'; Dir = (Join-Path (Get-RepoGitDir $Repo) 'hooks'); Original = $null; Scope = $null; Reset = $false; ChainDir = $null }
    }
    if ((ConvertTo-PosixPath $current) -eq $ours) {
        $orig = $state['original']
        $chainDir = if ($orig) { ConvertTo-PosixPath ([IO.Path]::GetFullPath($orig, $info.Path)) } else { $null }
        return [pscustomobject]@{ Mode = 'takeover'; Dir = $ours; Original = $orig; Scope = $state['scope']; Reset = $false; ChainDir = $chainDir }
    }
    # Someone else's hooksPath is active (fresh husky repo, or husky re-ran and reset it).
    $localVal = (Invoke-Git $info.Path @('config', '--local', '--get', 'core.hooksPath') -AllowFail) | Select-Object -First 1
    [pscustomobject]@{
        Mode     = 'takeover'
        Dir      = $ours
        Original = $current
        Scope    = if ($localVal) { 'local' } else { 'inherited' }
        Reset    = ($state['mode'] -eq 'takeover')
        ChainDir = ConvertTo-PosixPath ([IO.Path]::GetFullPath($current, $info.Path))
    }
}

function New-HookScript([string]$Repo, [string]$HookName, $Plan = $null) {
    if (-not $Plan) { $Plan = Get-HookPlan $Repo }
    $root = ConvertTo-PosixPath (Get-HarnessRoot)
    $failMissing = if ($HookName -like 'pre-*') { 'exit 1' } else { 'exit 0' }
    $chain = if ($Plan.Mode -eq 'takeover' -and $Plan.ChainDir) { "CHAIN='$($Plan.ChainDir)/$HookName'" }
             else { 'CHAIN="$HOOK_DIR/$HOOK_NAME.chained"' }
    @"
#!/bin/sh
$script:HookMarker
# Installed by aspen-harness ($($Plan.Mode) mode). Do not edit; re-run: ./harness.ps1 hooks install
HARNESS_ROOT='$root'
HARNESS_REPO='$Repo'
HOOK_NAME='$HookName'
HOOK_DIR=`$(dirname "`$0")
$chain
STDIN_DATA=''
if [ "`$HOOK_NAME" = "pre-push" ]; then STDIN_DATA=`$(cat); fi

if [ -x "`$CHAIN" ]; then
  printf '%s\n' "`$STDIN_DATA" | "`$CHAIN" "`$@" || exit `$?
fi

PWSH=`$(command -v pwsh 2>/dev/null || command -v pwsh.exe 2>/dev/null)
if [ -z "`$PWSH" ]; then
  echo "aspen-harness: pwsh not found; `$HOOK_NAME guard cannot run" >&2
  $failMissing
fi

printf '%s\n' "`$STDIN_DATA" | "`$PWSH" -NoProfile -NonInteractive -File "`$HARNESS_ROOT/hooks/guard.ps1" -Hook "`$HOOK_NAME" -Repo "`$HARNESS_REPO" "`$@"
"@ -replace "`r`n", "`n"
}

function Set-ExecutableBit([string]$Path) {
    if (-not $IsWindows) {
        [IO.File]::SetUnixFileMode($Path, [IO.UnixFileMode]'UserRead,UserWrite,UserExecute,GroupRead,GroupExecute,OtherRead,OtherExecute')
    }
}

function Install-HarnessHooks([string]$Repo) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $plan = Get-HookPlan $Repo
    New-Item -ItemType Directory -Force -Path $plan.Dir | Out-Null

    if ($plan.Mode -eq 'takeover') {
        if ($plan.Reset) { Write-HWarn "$Repo core.hooksPath was reset to '$($plan.Original)' (husky 'prepare'?); taking over again" }
        elseif ((Get-ConfiguredHooksPath $Repo) -ne $plan.Dir) { Write-HInfo "$Repo uses core.hooksPath='$($plan.Original)'; taking over locally, chaining to it" }
        Invoke-Git $info.Path @('config', '--local', 'core.hooksPath', $plan.Dir) | Out-Null
        Write-JsonFile (Get-HookStatePath $Repo) ([ordered]@{ mode = 'takeover'; original = $plan.Original; scope = $plan.Scope })
        $plan = Get-HookPlan $Repo
    }
    else {
        Remove-Item (Get-HookStatePath $Repo) -ErrorAction SilentlyContinue
    }

    foreach ($h in $script:HookNames) {
        $path = Join-Path $plan.Dir $h
        if ($plan.Mode -eq 'default' -and (Test-Path $path)) {
            $existing = Get-Content -Raw $path
            if ($existing -notmatch [regex]::Escape($script:HookMarker)) {
                $chained = "$path.chained"
                if (Test-Path $chained) { Stop-Harness "$h exists AND $h.chained exists in $($plan.Dir); resolve manually" }
                Move-Item $path $chained
                Write-HInfo "$Repo/${h}: existing hook preserved as $h.chained"
            }
        }
        (New-HookScript $Repo $h $plan) | Set-Content -Path $path -NoNewline -Encoding utf8
        Set-ExecutableBit $path
    }
    Write-HOk "$Repo hooks installed [$($plan.Mode)] ($($script:HookNames -join ', '))"
}

function Uninstall-HarnessHooks([string]$Repo) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $state = Read-JsonFile (Get-HookStatePath $Repo) @{}
    $defaultDir = Join-Path (Get-RepoGitDir $Repo) 'hooks'
    foreach ($h in $script:HookNames) {
        $path = Join-Path $defaultDir $h
        if ((Test-Path $path) -and ((Get-Content -Raw $path) -match [regex]::Escape($script:HookMarker))) {
            Remove-Item $path
            if (Test-Path "$path.chained") { Move-Item "$path.chained" $path; Write-HInfo "$Repo/${h}: original hook restored" }
        }
    }
    if ($state['mode'] -eq 'takeover') {
        if ($state['scope'] -eq 'local') { Invoke-Git $info.Path @('config', '--local', 'core.hooksPath', $state['original']) | Out-Null }
        else { Invoke-Git $info.Path @('config', '--local', '--unset', 'core.hooksPath') -AllowFail | Out-Null }
        Remove-Item (Get-TakeoverHooksDir $Repo) -Recurse -Force -ErrorAction SilentlyContinue
        Write-HInfo "$Repo core.hooksPath restored ($($state['scope']): $($state['original']))"
    }
    Remove-Item (Get-HookStatePath $Repo) -ErrorAction SilentlyContinue
    Write-HOk "$Repo harness hooks removed (guardrails OFF)"
}

function Get-HarnessHookStatus([string]$Repo) {
    Assert-RepoCloned $Repo
    $plan = Get-HookPlan $Repo
    $current = Get-ConfiguredHooksPath $Repo
    foreach ($h in $script:HookNames) {
        $status =
            if ($plan.Mode -eq 'takeover' -and $plan.Reset) { 'hooksPath-reset' }
            elseif ($plan.Mode -eq 'takeover' -and (ConvertTo-PosixPath $current) -ne $plan.Dir) { 'hooksPath-not-taken-over' }
            else {
                $path = Join-Path $plan.Dir $h
                if (-not (Test-Path $path)) { 'missing' }
                else {
                    $content = Get-Content -Raw $path
                    if ($content -notmatch [regex]::Escape($script:HookMarker)) { 'foreign' }
                    elseif ($content -ne (New-HookScript $Repo $h $plan)) { 'stale' }
                    else { 'current' }
                }
            }
        [pscustomobject]@{ Repo = $Repo; Hook = $h; Mode = $plan.Mode; Status = $status }
    }
}

#region Guard (called from hooks/guard.ps1)

# Paths that must never reach upstream unless explicitly bypassed.
function Get-ProtectedPaths([string]$Repo) {
    @(@(Get-PatchTargets $Repo) + @(Get-OverlaySourceFiles $Repo | ForEach-Object Rel) | Sort-Object -Unique)
}

function Get-BypassLog([string]$Repo) {
    $f = Join-Path (Get-RepoStateDir $Repo) 'bypass.log'
    if (-not (Test-Path $f)) { return @() }
    @(Get-Content $f | Where-Object { $_ } | ForEach-Object { $_ | ConvertFrom-Json -AsHashtable })
}

function Invoke-HarnessGuard([string]$Hook, [string]$Repo, [string[]]$HookArgs, [string[]]$StdinLines) {
    $info = Get-RepoInfo $Repo
    $stateDir = Get-RepoStateDir $Repo
    $pendingFile = Join-Path $stateDir 'bypass.pending'
    switch ($Hook) {
        'pre-commit' {
            $protected = Get-ProtectedPaths $Repo
            $staged = @(Invoke-Git $info.Path @('diff', '--cached', '--name-only', '--no-renames'))
            $hits = @($staged | Where-Object { $protected -contains $_ })
            if ($hits.Count -eq 0) { Remove-Item $pendingFile -ErrorAction SilentlyContinue; return 0 }
            if ($env:HARNESS_ALLOW_PATCHED -eq '1') {
                Set-Content -Path $pendingFile -Value ($hits -join "`n") -Encoding utf8
                [Console]::Error.WriteLine("aspen-harness: BYPASS - committing protected path(s): $($hits -join ', ') (logged)")
                return 0
            }
            [Console]::Error.WriteLine(@"
aspen-harness: commit blocked. Staged harness-managed path(s):
  $($hits -join "`n  ")
These carry local patches/overlay. Fix:
  ./harness.ps1 patch reset $Repo      (then re-stage)
  git restore --staged <path>          (unstage just these)
Legit upstream edit to one of these files? HARNESS_ALLOW_PATCHED=1 git commit ...
"@)
            return 1
        }
        'post-commit' {
            if (Test-Path $pendingFile) {
                $head = (Invoke-Git $info.Path @('rev-parse', 'HEAD')) | Select-Object -First 1
                $entry = [ordered]@{ commit = $head; files = @(Get-Content $pendingFile | Where-Object { $_ }); at = (Get-Date).ToString('o') }
                Add-Content -Path (Join-Path $stateDir 'bypass.log') -Value ($entry | ConvertTo-Json -Compress) -Encoding utf8
                Remove-Item $pendingFile
            }
            return 0
        }
        'pre-push' {
            $protected = Get-ProtectedPaths $Repo
            $allowed = @(Get-BypassLog $Repo | ForEach-Object { $_.commit })
            $zero = '0' * 40
            $violations = @()
            foreach ($line in @($StdinLines)) {
                $parts = -split $line
                if ($parts.Count -lt 4) { continue }
                $localSha = $parts[1]; $remoteSha = $parts[3]
                if ($localSha -eq $zero) { continue }   # branch delete
                $commits = $null
                if ($remoteSha -ne $zero) { $commits = Invoke-Git $info.Path @('rev-list', "$remoteSha..$localSha") -AllowFail }
                if ($null -eq $commits) { $commits = Invoke-Git $info.Path @('rev-list', $localSha, '--not', '--remotes=origin') }
                foreach ($c in @($commits)) {
                    $files = @(Invoke-Git $info.Path @('diff-tree', '--no-commit-id', '--name-only', '-r', '--root', '--no-renames', $c))
                    $hits = @($files | Where-Object { $protected -contains $_ })
                    if ($hits.Count -and $allowed -notcontains $c) { $violations += "$($c.Substring(0, 10)) $($hits -join ', ')" }
                }
            }
            if ($violations.Count -eq 0) { return 0 }
            [Console]::Error.WriteLine(@"
aspen-harness: push blocked. Outgoing commit(s) touch harness-managed paths without a logged bypass:
  $($violations -join "`n  ")
Rewrite them (git rebase -i / git commit --amend) or, if intended, recommit with HARNESS_ALLOW_PATCHED=1.
"@)
            return 1
        }
        { $_ -in 'post-checkout', 'post-merge' } {
            if ($Hook -eq 'post-checkout' -and @($HookArgs).Count -ge 3 -and $HookArgs[2] -ne '1') { return 0 }
            try {
                foreach ($s in @(Get-PatchStatus $Repo | Where-Object { $_.Drift })) {
                    [Console]::Error.WriteLine("aspen-harness: patch '$($s.Name)' drifted ($($s.Drift)); run ./harness.ps1 patch status $Repo")
                }
            }
            catch { }
            return 0
        }
        default { return 0 }
    }
}
#endregion
