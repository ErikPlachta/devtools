# Testbed: local bare "remotes" seeded with Angular/.NET-shaped files, plus
# simulated upstream commits. Lets the whole harness run with no network.

$script:UpstreamIdentity = @('-c', 'user.name=Upstream Dev', '-c', 'user.email=upstream@testbed.local', '-c', 'commit.gpgsign=false')

function Get-TestbedDir { Join-Path (Get-HarnessRoot) '.testbed' }

function Initialize-Testbed([switch]$Force) {
    $tb = Get-TestbedDir
    Write-HStep "testbed init: $tb"
    if (Test-Path $tb) {
        if (-not $Force) { Stop-Harness 'testbed exists; pass -Force to recreate (also delete repos/ to re-clone)' }
        Remove-Item $tb -Recurse -Force
    }
    New-Item -ItemType Directory -Force -Path $tb | Out-Null
    foreach ($repo in Get-HarnessRepoNames) {
        $seed = Join-Path (Get-HarnessRoot) 'testbed' 'seed' $repo
        if (-not (Test-Path $seed)) { Stop-Harness "no seed for '$repo' at $seed" }
        $info = Get-RepoInfo $repo
        $work = Join-Path $tb "seed-$repo"
        Copy-Item -Path $seed -Destination $work -Recurse
        Invoke-Git $work @('init', '--quiet', '-b', $info.DefaultBranch) | Out-Null
        Invoke-Git $work @('add', '--all') | Out-Null
        Invoke-Git $work ($script:UpstreamIdentity + @('commit', '--quiet', '-m', "Initial $repo")) | Out-Null
        $bare = Join-Path $tb "remote-$repo.git"
        Invoke-Git $tb @('clone', '--quiet', '--bare', $work, $bare) | Out-Null
        Remove-Item $work -Recurse -Force
        Write-HOk "remote-$repo.git"
    }
}

# Scenarios edit a scratch clone and push to the bare remote, as a teammate would.
$script:UpstreamScenarios = @{
    'app' = @{
        'unrelated'         = { param($w) Set-Content (Join-Path $w 'src/app/reports.service.ts') "export class ReportsService {}`n"; 'Add ReportsService' }
        'target-compatible' = { param($w) $f = Join-Path $w 'angular.json'; (Get-Content -Raw $f).Replace('"maximumWarning": "500kb"', '"maximumWarning": "750kb"') | Set-Content $f -NoNewline; 'Raise bundle budget' }
        'target-conflict'   = { param($w) $f = Join-Path $w 'angular.json'; (Get-Content -Raw $f).Replace('"port": 4200', '"port": 4201') | Set-Content $f -NoNewline; 'Move dev server to 4201' }
    }
    'api' = @{
        'unrelated'         = { param($w) Set-Content (Join-Path $w 'src/Aspen.Api/HealthController.cs') "namespace Aspen.Api;`npublic class HealthController {}`n"; 'Add HealthController' }
        'target-compatible' = { param($w) $f = Join-Path $w 'src/Aspen.Api/Properties/launchSettings.json'; (Get-Content -Raw $f) -replace '"profiles": \{(\r?\n)', ('"profiles": {$1    "http": {$1      "commandName": "Project",$1      "applicationUrl": "http://localhost:5001"$1    },$1') | Set-Content $f -NoNewline; 'Add http-only profile' }
        'target-conflict'   = { param($w) $f = Join-Path $w 'src/Aspen.Api/Properties/launchSettings.json'; (Get-Content -Raw $f).Replace('https://localhost:7001', 'https://localhost:7002') | Set-Content $f -NoNewline; 'Move https port to 7002' }
    }
}

function Invoke-UpstreamChange([string]$Repo, [string]$Scenario) {
    $scen = $script:UpstreamScenarios[$Repo]
    if (-not $scen -or -not $scen.ContainsKey($Scenario)) {
        Stop-Harness "unknown scenario '$Scenario' for '$Repo' (known: $(@($scen.Keys) -join ', '))"
    }
    $info = Get-RepoInfo $Repo
    if ($info.Mode -ne 'testbed') { Stop-Harness 'upstream simulation only runs in testbed mode' }
    $work = Join-Path (Get-TestbedDir) "work-$Repo-$([guid]::NewGuid().ToString('N').Substring(0, 8))"
    try {
        Invoke-Git (Get-TestbedDir) @('clone', '--quiet', $info.RemoteUrl, $work) | Out-Null
        $msg = & $scen[$Scenario] $work
        Invoke-Git $work @('add', '--all') | Out-Null
        Invoke-Git $work ($script:UpstreamIdentity + @('commit', '--quiet', '-m', $msg)) | Out-Null
        Invoke-Git $work @('push', '--quiet', 'origin', 'HEAD') | Out-Null
        Write-HOk "upstream ${Repo}: '$msg' pushed (run ./harness.ps1 sync $Repo)"
    }
    finally { Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue }
}
