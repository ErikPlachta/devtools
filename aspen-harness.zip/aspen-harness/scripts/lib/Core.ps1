# Core: config, paths, git wrapper, JSON/state helpers, output.

$script:HarnessRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..' '..'))
[Console]::OutputEncoding = [Text.Encoding]::UTF8

#region Output
function Write-HInfo([string]$Message) { Write-Host "  $Message" }
function Write-HStep([string]$Message) { Write-Host "> $Message" -ForegroundColor Cyan }
function Write-HOk([string]$Message)   { Write-Host "  ok: $Message" -ForegroundColor Green }
function Write-HWarn([string]$Message) { Write-Host "  warn: $Message" -ForegroundColor Yellow }
function Stop-Harness([string]$Message) { throw "harness: $Message" }
#endregion

#region Config
function Get-HarnessRoot { $script:HarnessRoot }

function Get-HarnessConfig {
    $path = Join-Path $script:HarnessRoot 'harness.json'
    if (-not (Test-Path $path)) { Stop-Harness "harness.json not found at $path" }
    Get-Content -Raw $path | ConvertFrom-Json -AsHashtable
}

function Get-HarnessRepoNames { @((Get-HarnessConfig).repos.Keys | Sort-Object) }

function Get-RepoInfo([string]$Repo) {
    $cfg = Get-HarnessConfig
    if (-not $cfg.repos.ContainsKey($Repo)) {
        Stop-Harness "unknown repo '$Repo' (known: $((Get-HarnessRepoNames) -join ', '))"
    }
    $r = $cfg.repos[$Repo]
    $mode = $cfg.mode
    $url = $r.remotes[$mode]
    if (-not $url) { Stop-Harness "repo '$Repo' has no remote for mode '$mode'" }
    # Testbed remotes are relative to harness root.
    if ($mode -eq 'testbed' -and -not [IO.Path]::IsPathRooted($url)) {
        $url = [IO.Path]::GetFullPath((Join-Path $script:HarnessRoot $url))
    }
    [pscustomobject]@{
        Name          = $Repo
        Path          = [IO.Path]::GetFullPath((Join-Path $script:HarnessRoot $r.path))
        RelPath       = $r.path
        DefaultBranch = $r.defaultBranch
        RemoteUrl     = $url
        Mode          = $mode
        CheckCommand  = $r.checkCommand
        CloneConfig   = if ($cfg.ContainsKey('cloneConfig') -and $cfg.cloneConfig) { $cfg.cloneConfig } else { @{} }
    }
}

function Test-RepoCloned([string]$Repo) {
    Test-Path (Join-Path (Get-RepoInfo $Repo).Path '.git')
}

function Assert-RepoCloned([string]$Repo) {
    if (-not (Test-RepoCloned $Repo)) { Stop-Harness "repo '$Repo' not cloned; run: ./harness.ps1 sync" }
}
#endregion

#region Git
function Invoke-GitRaw([string]$Path, [string[]]$GitArgs) {
    $errFile = [IO.Path]::GetTempFileName()
    try {
        $out = & git -C $Path @GitArgs 2>$errFile
        $code = $LASTEXITCODE
        $err = Get-Content -Raw $errFile
    }
    finally { Remove-Item $errFile -ErrorAction SilentlyContinue }
    [pscustomobject]@{ Code = $code; Out = @($out | Where-Object { $null -ne $_ }); Err = "$err".Trim() }
}

function Invoke-Git([string]$Path, [string[]]$GitArgs, [switch]$AllowFail) {
    $r = Invoke-GitRaw $Path $GitArgs
    if ($r.Code -ne 0 -and -not $AllowFail) {
        Stop-Harness "git $($GitArgs -join ' ') failed ($($r.Code)) in ${Path}:`n$($r.Err)"
    }
    if ($r.Code -ne 0) { return $null }
    $r.Out
}

function Get-RepoGitDir([string]$Repo) {
    $p = (Get-RepoInfo $Repo).Path
    (Invoke-Git $p @('rev-parse', '--absolute-git-dir')) | Select-Object -First 1
}

function Get-RepoStateDir([string]$Repo) {
    $d = Join-Path (Get-RepoGitDir $Repo) 'harness'
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    $d
}

# Blob id of a path at a ref (HEAD, origin/main...). $null if absent.
function Get-RefBlob([string]$Repo, [string]$Ref, [string]$RelPath) {
    $p = (Get-RepoInfo $Repo).Path
    (Invoke-Git $p @('rev-parse', '--verify', '--quiet', "${Ref}:$RelPath") -AllowFail) | Select-Object -First 1
}

# Blob id of the working-tree file (clean filters applied). $null if missing.
function Get-WorktreeBlob([string]$Repo, [string]$RelPath) {
    $p = (Get-RepoInfo $Repo).Path
    if (-not (Test-Path (Join-Path $p $RelPath))) { return $null }
    (Invoke-Git $p @('hash-object', '--', $RelPath)) | Select-Object -First 1
}

function Get-CurrentBranch([string]$Repo) {
    $p = (Get-RepoInfo $Repo).Path
    (Invoke-Git $p @('symbolic-ref', '--quiet', '--short', 'HEAD') -AllowFail) | Select-Object -First 1
}

# Paths with working-tree/index changes (excluded + ignored files never appear).
function Get-DirtyPaths([string]$Repo) {
    $p = (Get-RepoInfo $Repo).Path
    $lines = Invoke-Git $p @('status', '--porcelain=v1', '--untracked-files=all')
    foreach ($l in @($lines)) {
        if ($l.Length -lt 4) { continue }
        $path = $l.Substring(3)
        if ($path -match ' -> ') { $path = ($path -split ' -> ')[-1] }
        $path.Trim('"')
    }
}
#endregion

#region JSON / files
function Read-JsonFile([string]$Path, $Default) {
    if (-not (Test-Path $Path)) { return $Default }
    $raw = Get-Content -Raw $Path
    if ([string]::IsNullOrWhiteSpace($raw)) { return $Default }
    $raw | ConvertFrom-Json -AsHashtable
}

function Write-JsonFile([string]$Path, $Object) {
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    ($Object | ConvertTo-Json -Depth 10) + "`n" | Set-Content -Path $Path -NoNewline -Encoding utf8
}

function Get-FileSha256([string]$Path) { (Get-FileHash -Algorithm SHA256 -Path $Path).Hash.ToLowerInvariant() }

function Remove-EmptyParentDirs([string]$File, [string]$StopAt) {
    $dir = Split-Path $File -Parent
    $stop = [IO.Path]::GetFullPath($StopAt).TrimEnd([IO.Path]::DirectorySeparatorChar)
    while ($dir -and ([IO.Path]::GetFullPath($dir).TrimEnd([IO.Path]::DirectorySeparatorChar) -ne $stop)) {
        if (@(Get-ChildItem -Force -Path $dir).Count -gt 0) { break }
        Remove-Item -Path $dir -Force
        $dir = Split-Path $dir -Parent
    }
}
#endregion
