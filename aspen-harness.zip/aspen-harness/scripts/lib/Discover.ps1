# Phase 0 discovery: inspect a clone (the harness clone, or your EXISTING working copy via -Path)
# and report harness risks plus a tier suggestion for every current local edit. Read-only.

function Get-TierSuggestion([string]$RelPath, [string]$Kind) {
    $name = Split-Path $RelPath -Leaf
    if ($Kind -eq 'untracked') {
        return @('3', "overlay: copy to overlay/<repo>/$RelPath")
    }
    switch -Regex ($name) {
        '^appsettings(\..+)?\.json$' { return @('1', 'user-secrets (secrets apply) or env vars Section__Key in workspace launch/task env') }
        '^launchSettings\.json$'     { return @('4', 'patch new; or Tier 1: put urls/env in the workspace launch config and drop the edit') }
        '^angular\.json$'            { return @('4', 'patch new; port/proxy can be Tier 1 via ng serve --port / --proxy-config') }
        '^package\.json$'            { return @('1/4', 'script tweaks -> run commands from workspace tasks (Tier 1); dependency changes -> feature or patch') }
        '^environment.*\.ts$'        { return @('4', 'patch new; long-term: upstream a gitignored local fileReplacements config (Phase 10)') }
        '^proxy\.conf.*\.json$'      { return @('1', 'keep your proxy in harness config/ and pass --proxy-config') }
        '\.csproj$|^Directory\.Build\.(props|targets)$' { return @('2/4', 'property tweak -> harness-root Directory.Build.props (if not blocked); else patch') }
        '^nuget\.config$'            { return @('2', 'harness-root nuget.config (NuGet merges configs up the tree)') }
        '^\.npmrc$'                  { return @('1', 'npm does NOT read parent .npmrc: use ~/.npmrc or NPM_CONFIG_* env vars') }
        '^\.editorconfig$'           { return @('2', 'harness-root .editorconfig (only if repo file lacks root=true)') }
        default                      { return @('4?', 'review: local-env tweak (patch new) or actual feature work?') }
    }
}

function Invoke-HarnessDiscover([string]$Repo, [string]$Path = '') {
    $bt = [char]96   # markdown code backtick
    if (-not $Path) {
        Assert-RepoCloned $Repo
        $Path = (Get-RepoInfo $Repo).Path
        $isHarnessClone = $true
    }
    else {
        $Path = [IO.Path]::GetFullPath($Path)
        $isHarnessClone = $false
    }
    if (-not (Invoke-Git $Path @('rev-parse', '--is-inside-work-tree') -AllowFail)) { Stop-Harness "not a git work tree: $Path" }
    $top = (Invoke-Git $Path @('rev-parse', '--show-toplevel')) | Select-Object -First 1
    function GitQ([string[]]$a) { Invoke-Git $top $a -AllowFail }
    function Exists([string]$rel) { Test-Path (Join-Path $top $rel) }

    $risks = [Collections.Generic.List[string]]::new()
    $facts = [Collections.Generic.List[string]]::new()

    $origin = (GitQ @('remote', 'get-url', 'origin')) | Select-Object -First 1
    $headRef = (GitQ @('symbolic-ref', '--quiet', 'refs/remotes/origin/HEAD')) | Select-Object -First 1
    $default = if ($headRef) { $headRef -replace '^refs/remotes/origin/', '' } else { '(unknown: run git remote set-head origin -a)' }
    $branch = (GitQ @('symbolic-ref', '--quiet', '--short', 'HEAD')) | Select-Object -First 1
    $facts.Add("origin: ${bt}$origin${bt}")
    $facts.Add("default branch: ${bt}$default${bt} (set ${bt}defaultBranch${bt} in harness.json)")
    $facts.Add("current branch: ${bt}$(if ($branch) { $branch } else { '(detached)' })${bt}")

    # Hooks
    $hooksPath = (GitQ @('config', '--get', 'core.hooksPath')) | Select-Object -First 1
    $huskyDir = Exists '.husky'
    $prepare = $null
    if (Exists 'package.json') {
        try { $prepare = (Get-Content -Raw (Join-Path $top 'package.json') | ConvertFrom-Json -AsHashtable).scripts.prepare } catch { }
    }
    if ($hooksPath -or $huskyDir -or ("$prepare" -match 'husky')) {
        $risks.Add("**Hooks:** core.hooksPath=${bt}$hooksPath${bt}, .husky=$huskyDir, prepare=${bt}$prepare${bt}. Harness uses local takeover and chains to it. " +
            "${bt}npm install${bt} re-running husky resets hooksPath: doctor flags it, ${bt}sync${bt}/${bt}hooks install${bt} re-takes. Verify after first ${bt}npm ci${bt}.")
    }
    else { $facts.Add('hooks: no core.hooksPath / husky (default hook mode)') }

    # Line endings
    $autocrlf = (GitQ @('config', '--get', 'core.autocrlf')) | Select-Object -First 1
    $facts.Add("core.autocrlf: ${bt}$(if ($autocrlf) { $autocrlf } else { 'unset' })${bt}")
    if ($autocrlf -eq 'true') { $risks.Add("**Line endings:** core.autocrlf=true; patches may fail on CRLF worktrees. Harness clones use ${bt}input${bt} (harness.json cloneConfig).") }
    if (Exists '.gitattributes') {
        $eol = @(Get-Content (Join-Path $top '.gitattributes') | Where-Object { $_ -match 'eol=|text' }).Count
        $facts.Add(".gitattributes: present ($eol text/eol rule(s))")
    }

    # Tier 2 blockers
    foreach ($f in 'Directory.Build.props', 'Directory.Build.targets') {
        $hits = @(GitQ @('ls-files', '--', "*$f"))
        foreach ($h in $hits) {
            $chains = Select-String -Path (Join-Path $top $h) -Pattern 'GetPathOfFileAbove' -Quiet
            if ($chains) { $facts.Add("${bt}$h${bt} chains upward (GetPathOfFileAbove): harness ${bt}$f${bt} is inherited") }
            else { $risks.Add("**Tier 2 blocked:** ${bt}$h${bt} exists and does not import upward; harness-root ${bt}$f${bt} will NOT apply below it.") }
        }
    }
    $ec = Join-Path $top '.editorconfig'
    if ((Test-Path $ec) -and (Select-String -Path $ec -Pattern '^\s*root\s*=\s*true' -Quiet)) {
        $facts.Add('.editorconfig has root=true: harness-root .editorconfig ignored (expected)')
    }
    if (Exists '.npmrc') { $facts.Add('.npmrc tracked at repo root (npm never reads a parent-dir .npmrc; use ~/.npmrc or NPM_CONFIG_*)') }

    # Project shape
    $launch = @(GitQ @('ls-files', '--', '*launchSettings.json'))
    $facts.Add("launchSettings.json tracked: $(if ($launch.Count) { ($launch | ForEach-Object { "${bt}$_${bt}" }) -join ', ' } else { 'no' })")
    $csproj = @(GitQ @('ls-files', '--', '*.csproj'))
    foreach ($c in $csproj) {
        $id = Select-String -Path (Join-Path $top $c) -Pattern '<UserSecretsId>' -Quiet
        $facts.Add("${bt}$c${bt}: UserSecretsId $(if ($id) { 'present (secrets apply works)' } else { 'absent (secrets apply blocked; use env vars)' })")
    }
    if (Exists 'angular.json') {
        $aj = Get-Content -Raw (Join-Path $top 'angular.json')
        $facts.Add("angular.json: proxyConfig $(if ($aj -match '"proxyConfig"') { 'set in repo' } else { 'not set (pass --proxy-config from harness)' })")
    }

    # Local edits inventory (harness-managed paths are labelled, not re-suggested)
    $managedPatch = @{}
    $managedOverlay = @()
    if ($isHarnessClone) {
        foreach ($p in (Get-PatchManifest $Repo).patches) { foreach ($t in $p.targets) { $managedPatch[$t] = $p.name } }
        $managedOverlay = @(Get-OverlaySourceFiles $Repo | ForEach-Object Rel)
    }
    $rows = [Collections.Generic.List[string]]::new()
    $numstat = @{}
    foreach ($l in @(GitQ @('diff', 'HEAD', '--numstat'))) {
        $p = $l -split "`t"
        if ($p.Count -ge 3) { $numstat[$p[2]] = "+$($p[0])/-$($p[1])" }
    }
    foreach ($l in @(GitQ @('status', '--porcelain=v1', '--untracked-files=all'))) {
        if ($l.Length -lt 4) { continue }
        $xy = $l.Substring(0, 2); $rel = $l.Substring(3).Trim('"')
        if ($rel -match ' -> ') { $rel = ($rel -split ' -> ')[-1] }
        $kind = if ($xy -eq '??') { 'untracked' } elseif ($xy -match 'D') { 'deleted' } else { 'modified' }
        $tier, $how = Get-TierSuggestion $rel $kind
        if ($managedPatch.ContainsKey($rel)) { $tier = 'managed'; $how = "harness patch '$($managedPatch[$rel])'" }
        elseif ($managedOverlay -contains $rel) { $tier = 'managed'; $how = 'harness overlay' }
        $delta = $numstat[$rel] ?? ''
        $rows.Add("| ${bt}$rel${bt} | $kind $delta | $tier | $how |")
    }
    $stashes = @(GitQ @('stash', 'list'))

    # Render
    $sb = [Text.StringBuilder]::new()
    [void]$sb.AppendLine("# Phase 0 discovery: $Repo")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("Scanned: ${bt}$top${bt} $(if ($isHarnessClone) { '(harness clone)' } else { '(existing working copy)' }) on $(Get-Date -Format 'yyyy-MM-dd HH:mm')")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Risks')
    if ($risks.Count) { $risks | ForEach-Object { [void]$sb.AppendLine("- $_") } } else { [void]$sb.AppendLine('- none detected') }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Facts')
    $facts | ForEach-Object { [void]$sb.AppendLine("- $_") }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Local edits -> tier')
    if ($rows.Count) {
        [void]$sb.AppendLine('| Path | Change | Tier | How |')
        [void]$sb.AppendLine('|---|---|---|---|')
        $rows | ForEach-Object { [void]$sb.AppendLine($_) }
    }
    else { [void]$sb.AppendLine('No uncommitted changes. If you keep local edits stashed, apply them first or inspect the stashes below.') }
    if ($stashes.Count) {
        [void]$sb.AppendLine()
        [void]$sb.AppendLine("## Stashes ($($stashes.Count)): may hold local config edits")
        $stashes | ForEach-Object { [void]$sb.AppendLine("- $_") }
    }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Next')
    [void]$sb.AppendLine('- Prefer the lowest tier. Tier 4 only for edits with no Tier 1-3 route; note each in the Phase 10 upstream PR list.')
    if ($isHarnessClone) {
        [void]$sb.AppendLine("- Capture a Tier 4 edit: ${bt}./harness.ps1 patch new $Repo <name> <path> -Reason ""..."" -RetireWhen ""...""${bt}")
    }
    else {
        [void]$sb.AppendLine("- Recreate edits in the harness clone (${bt}repos/$Repo${bt}), then ${bt}patch new${bt}. Don't copy files wholesale: re-make only the local deltas.")
    }
    $sb.ToString()
}
