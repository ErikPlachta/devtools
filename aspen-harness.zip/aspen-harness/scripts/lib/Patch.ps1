# Tier 4: patch framework. Local edits to TRACKED upstream files, stored as diffs in
# patches/<repo>/ with a manifest. Apply/reset are transactional; drift is detected
# against the upstream blob each patch was created from.
#
# manifest.json: { patches: [ { name, file, targets[], reason, retireWhen, created, baseBlobs{path:blob} } ] }
# state (repos/<repo>/.git/harness/patches.json): { applied: [names in apply order], post: {path: blob} }

function Get-PatchDir([string]$Repo) { Join-Path (Get-HarnessRoot) 'patches' $Repo }
function Get-PatchManifestPath([string]$Repo) { Join-Path (Get-PatchDir $Repo) 'manifest.json' }

function Get-PatchManifest([string]$Repo) {
    $m = Read-JsonFile (Get-PatchManifestPath $Repo) @{ patches = @() }
    $m.patches = @($m.patches)
    $m
}

function Save-PatchManifest([string]$Repo, $Manifest) {
    Write-JsonFile (Get-PatchManifestPath $Repo) ([ordered]@{ patches = @($Manifest.patches) })
}

function Get-PatchStatePath([string]$Repo) { Join-Path (Get-RepoStateDir $Repo) 'patches.json' }

function Get-PatchState([string]$Repo) {
    $s = Read-JsonFile (Get-PatchStatePath $Repo) @{ applied = @(); post = @{} }
    $s.applied = @($s.applied)
    if (-not $s.post) { $s.post = @{} }
    $s
}

function Save-PatchState([string]$Repo, $State) {
    if (@($State.applied).Count -eq 0) { Remove-Item (Get-PatchStatePath $Repo) -ErrorAction SilentlyContinue; return }
    Write-JsonFile (Get-PatchStatePath $Repo) ([ordered]@{ applied = @($State.applied); post = $State.post })
}

function Get-PatchTargets([string]$Repo) {
    @((Get-PatchManifest $Repo).patches | ForEach-Object { $_.targets } | Sort-Object -Unique)
}

function Get-PatchEntry([string]$Repo, [string]$Name) {
    $p = (Get-PatchManifest $Repo).patches | Where-Object { $_.name -eq $Name } | Select-Object -First 1
    if (-not $p) { Stop-Harness "no patch '$Name' in patches/$Repo/manifest.json" }
    $p
}

function Get-PatchFilePath([string]$Repo, $Entry) { Join-Path (Get-PatchDir $Repo) $Entry.file }

function Invoke-PatchApply([string]$Repo) {
    Assert-RepoCloned $Repo
    Write-HStep "patch apply: $Repo"
    $info = Get-RepoInfo $Repo
    $manifest = Get-PatchManifest $Repo
    $state = Get-PatchState $Repo
    $pending = @($manifest.patches | Where-Object { $state.applied -notcontains $_.name })
    if ($manifest.patches.Count -eq 0) { Write-HInfo 'no patches'; return }
    if ($pending.Count -eq 0) { Write-HOk 'all patches already applied'; return }
    if (Test-Path (Join-Path (Get-RepoStateDir $Repo) 'refresh.pending')) {
        Stop-Harness "a patch refresh is in progress; finish it first (patch refresh <repo> <name> -Finish)"
    }

    # Targets of pending patches must be clean (unless already carrying an applied patch).
    $appliedTargets = @($state.post.Keys)
    $pendingTargets = @($pending | ForEach-Object { $_.targets } | Sort-Object -Unique)
    $dirty = @(Get-DirtyPaths $Repo | Where-Object { $pendingTargets -contains $_ -and $appliedTargets -notcontains $_ })
    if ($dirty.Count -gt 0) {
        Stop-Harness "patch targets have uncommitted changes: $($dirty -join ', '). Commit/stash them, or capture with 'patch new'."
    }

    foreach ($p in $pending) {
        foreach ($t in $p.targets) {
            $head = Get-RefBlob $Repo 'HEAD' $t
            if ($head -ne $p.baseBlobs[$t]) { Write-HWarn "drift: '$($p.name)' was made against a different version of $t" }
        }
    }

    $done = [Collections.Generic.List[object]]::new()
    try {
        foreach ($p in $pending) {
            $file = Get-PatchFilePath $Repo $p
            if (-not (Test-Path $file)) { throw "patch file missing: $file" }
            $r = Invoke-GitRaw $info.Path @('apply', '--whitespace=nowarn', $file)
            if ($r.Code -ne 0) { throw "patch '$($p.name)' does not apply:`n$($r.Err)" }
            $done.Add($p)
        }
    }
    catch {
        for ($i = $done.Count - 1; $i -ge 0; $i--) {
            $null = Invoke-GitRaw $info.Path @('apply', '-R', '--whitespace=nowarn', (Get-PatchFilePath $Repo $done[$i]))
        }
        Stop-Harness "$($_.Exception.Message)`nRolled back $($done.Count) patch(es); nothing applied. Fix with: ./harness.ps1 patch refresh $Repo <name>"
    }

    foreach ($p in $done) {
        $state.applied = @($state.applied) + $p.name
        foreach ($t in $p.targets) { $state.post[$t] = Get-WorktreeBlob $Repo $t }
    }
    Save-PatchState $Repo $state
    Write-HOk "$($done.Count) patch(es) applied: $(($done | ForEach-Object name) -join ', ')"
}

function Invoke-PatchReset([string]$Repo) {
    Assert-RepoCloned $Repo
    Write-HStep "patch reset: $Repo"
    $info = Get-RepoInfo $Repo
    $state = Get-PatchState $Repo
    if ($state.applied.Count -eq 0) { Write-HInfo 'no patches applied'; return }

    # Never discard user work: targets must be exactly as the patches left them.
    $modified = @(foreach ($t in $state.post.Keys) {
        if ((Get-WorktreeBlob $Repo $t) -ne $state.post[$t]) { $t }
    })
    if ($modified.Count -gt 0) {
        Stop-Harness ("patched files modified beyond the patch: $($modified -join ', ').`n" +
            "  Feature change? move it out of the file or commit with HARNESS_ALLOW_PATCHED=1.`n" +
            "  Local-env change? capture it: reset manually, then 'patch new' / 'patch refresh'.")
    }

    $manifest = Get-PatchManifest $Repo
    $applied = @($state.applied)
    for ($i = $applied.Count - 1; $i -ge 0; $i--) {
        $entry = $manifest.patches | Where-Object { $_.name -eq $applied[$i] } | Select-Object -First 1
        if (-not $entry) { Stop-Harness "applied patch '$($applied[$i])' no longer in manifest; restore it or reset targets manually" }
        $r = Invoke-GitRaw $info.Path @('apply', '-R', '--whitespace=nowarn', (Get-PatchFilePath $Repo $entry))
        if ($r.Code -ne 0) { Stop-Harness "reverse of '$($entry.name)' failed:`n$($r.Err)" }
        foreach ($t in $entry.targets) { $state.post.Remove($t) }
        $state.applied = @($state.applied | Where-Object { $_ -ne $entry.name })
        Save-PatchState $Repo $state
    }
    Write-HOk "$($applied.Count) patch(es) reset"
}

function Get-PatchStatus([string]$Repo) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $state = Get-PatchState $Repo
    $origin = "origin/$($info.DefaultBranch)"
    foreach ($p in (Get-PatchManifest $Repo).patches) {
        $applied = $state.applied -contains $p.name
        $drift = @()
        $dirty = $false
        foreach ($t in $p.targets) {
            if ((Get-RefBlob $Repo 'HEAD' $t) -ne $p.baseBlobs[$t]) { $drift += "HEAD:$t" }
            elseif ((Get-RefBlob $Repo $origin $t) -ne $p.baseBlobs[$t]) { $drift += "${origin}:$t" }
            if ($applied -and (Get-WorktreeBlob $Repo $t) -ne $state.post[$t]) { $dirty = $true }
        }
        [pscustomobject]@{
            Repo    = $Repo
            Name    = $p.name
            Applied = $applied
            Drift   = if ($drift.Count) { $drift -join ', ' } else { '' }
            Dirty   = $dirty
            Targets = ($p.targets -join ', ')
        }
    }
}

function New-HarnessPatch([string]$Repo, [string]$Name, [string[]]$Targets, [string]$Reason = '', [string]$RetireWhen = '') {
    Assert-RepoCloned $Repo
    Write-HStep "patch new: $Repo/$Name"
    if ($Name -notmatch '^[a-z0-9][a-z0-9-]*$') { Stop-Harness "patch name must be kebab-case: '$Name'" }
    if (@($Targets).Count -eq 0) { Stop-Harness 'specify at least one target file' }
    $info = Get-RepoInfo $Repo
    $manifest = Get-PatchManifest $Repo
    if ($manifest.patches | Where-Object { $_.name -eq $Name }) { Stop-Harness "patch '$Name' already exists" }
    $state = Get-PatchState $Repo
    $Targets = @($Targets | ForEach-Object { $_.Replace('\', '/') })
    foreach ($t in $Targets) {
        if (-not (Get-RefBlob $Repo 'HEAD' $t)) { Stop-Harness "$t is not tracked at HEAD; untracked local files belong in overlay/" }
        if ($state.post.ContainsKey($t)) { Stop-Harness "$t already carries an applied patch; reset first, or use 'patch refresh' to amend" }
    }

    $nums = @($manifest.patches | ForEach-Object { if ($_.file -match '^(\d+)-') { [int]$Matches[1] } })
    $next = if ($nums.Count) { ($nums | Measure-Object -Maximum).Maximum + 1 } else { 1 }
    $fileName = '{0:D3}-{1}.patch' -f $next, $Name
    $patchPath = Join-Path (Get-PatchDir $Repo) $fileName
    New-Item -ItemType Directory -Force -Path (Get-PatchDir $Repo) | Out-Null
    Invoke-Git $info.Path (@('diff', '--no-color', '--no-ext-diff', "--output=$patchPath", '--') + $Targets) | Out-Null
    if ((Get-Item $patchPath).Length -eq 0) {
        Remove-Item $patchPath
        Stop-Harness "no working-tree changes in: $($Targets -join ', ')"
    }

    $base = [ordered]@{}
    foreach ($t in $Targets) { $base[$t] = Get-RefBlob $Repo 'HEAD' $t }
    $entry = [ordered]@{
        name = $Name; file = $fileName; targets = $Targets
        reason = $Reason; retireWhen = $RetireWhen
        created = (Get-Date).ToString('yyyy-MM-dd'); baseBlobs = $base
    }
    $manifest.patches = @($manifest.patches) + $entry
    Save-PatchManifest $Repo $manifest

    # The edits are live in the worktree, so the new patch counts as applied.
    $state.applied = @($state.applied) + $Name
    foreach ($t in $Targets) { $state.post[$t] = Get-WorktreeBlob $Repo $t }
    Save-PatchState $Repo $state
    Write-HOk "created patches/$Repo/$fileName (applied)"
}

# Rebase a patch onto the current upstream version of its targets.
#   start : 3-way apply; clean -> finishes automatically; conflict -> resolve markers, then -Finish
#   -Finish: regenerate the diff from the working tree, update baseBlobs, mark applied
function Invoke-PatchRefresh([string]$Repo, [string]$Name, [switch]$Finish) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $entry = Get-PatchEntry $Repo $Name
    $pendingFile = Join-Path (Get-RepoStateDir $Repo) 'refresh.pending'
    $state = Get-PatchState $Repo

    if (-not $Finish) {
        Write-HStep "patch refresh: $Repo/$Name"
        if ($state.applied.Count -gt 0) { Stop-Harness "reset patches first: ./harness.ps1 patch reset $Repo" }
        $dirty = @(Get-DirtyPaths $Repo | Where-Object { $entry.targets -contains $_ })
        if ($dirty.Count) { Stop-Harness "targets not clean: $($dirty -join ', ')" }
        $r = Invoke-GitRaw $info.Path @('apply', '--3way', '--whitespace=nowarn', (Get-PatchFilePath $Repo $entry))
        if ($r.Code -eq 0) {
            Write-HInfo 'applied cleanly against current upstream'
        }
        else {
            Set-Content -Path $pendingFile -Value $Name -Encoding utf8
            Write-HWarn "conflicts in: $($entry.targets -join ', ')"
            Write-HInfo "resolve the markers (or hand-edit the file to the desired local state), then run:"
            Write-HInfo "  ./harness.ps1 patch refresh $Repo $Name -Finish"
            if ($r.Err) { Write-HInfo $r.Err }
            return
        }
    }
    else {
        Write-HStep "patch refresh -Finish: $Repo/$Name"
    }

    foreach ($t in $entry.targets) {
        $full = Join-Path $info.Path $t
        if ((Test-Path $full) -and (Select-String -Path $full -Pattern '^(<{7}|>{7})( |$)' -Quiet)) {
            Stop-Harness "conflict markers remain in $t"
        }
    }
    # --3way stages paths; unstage so nothing local sits in the index.
    Invoke-Git $info.Path (@('reset', '-q', '--') + $entry.targets) -AllowFail | Out-Null
    $patchPath = Get-PatchFilePath $Repo $entry
    Invoke-Git $info.Path (@('diff', '--no-color', '--no-ext-diff', "--output=$patchPath", 'HEAD', '--') + @($entry.targets)) | Out-Null
    if ((Get-Item $patchPath).Length -eq 0) { Stop-Harness "refreshed patch is empty; use 'patch retire $Repo $Name' if no longer needed" }

    $manifest = Get-PatchManifest $Repo
    foreach ($p in $manifest.patches) {
        if ($p.name -ne $Name) { continue }
        $base = [ordered]@{}
        foreach ($t in $p.targets) { $base[$t] = Get-RefBlob $Repo 'HEAD' $t }
        $p.baseBlobs = $base
        $p['refreshed'] = (Get-Date).ToString('yyyy-MM-dd')
    }
    Save-PatchManifest $Repo $manifest
    $state.applied = @($state.applied | Where-Object { $_ -ne $Name }) + $Name
    foreach ($t in $entry.targets) { $state.post[$t] = Get-WorktreeBlob $Repo $t }
    Save-PatchState $Repo $state
    Remove-Item $pendingFile -ErrorAction SilentlyContinue
    Write-HOk "patch '$Name' refreshed against HEAD and applied"
}

function Remove-HarnessPatch([string]$Repo, [string]$Name) {
    Write-HStep "patch retire: $Repo/$Name"
    $entry = Get-PatchEntry $Repo $Name
    if (Test-RepoCloned $Repo) {
        if ((Get-PatchState $Repo).applied -contains $Name) { Stop-Harness "patch '$Name' is applied; run 'patch reset $Repo' first" }
    }
    $manifest = Get-PatchManifest $Repo
    $manifest.patches = @($manifest.patches | Where-Object { $_.name -ne $Name })
    Save-PatchManifest $Repo $manifest
    Remove-Item (Get-PatchFilePath $Repo $entry) -ErrorAction SilentlyContinue
    Write-HOk "retired '$Name'"
}
