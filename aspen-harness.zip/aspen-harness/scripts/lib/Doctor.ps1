# Doctor: verify harness invariants. Returns check rows; FAIL rows mean exit 1.

function Invoke-HarnessDoctor {
    $rows = [Collections.Generic.List[object]]::new()
    function Add-Check($Scope, $Check, $Level, $Detail = '') {
        $rows.Add([pscustomobject]@{ Level = $Level; Scope = $Scope; Check = $Check; Detail = $Detail })
    }
    $root = Get-HarnessRoot

    # Harness repo
    if (Test-Path (Join-Path $root '.git')) { Add-Check 'harness' 'git repo' 'OK' }
    else { Add-Check 'harness' 'git repo' 'WARN' "not a git repo; run 'git init' in $root to version your harness" }
    $gi = Join-Path $root '.gitignore'
    if ((Test-Path $gi) -and (@(Get-Content $gi) -contains '/repos/')) { Add-Check 'harness' '.gitignore has /repos/' 'OK' }
    else { Add-Check 'harness' '.gitignore has /repos/' 'FAIL' 'clones would be tracked by the harness repo' }
    $gitVer = ((git --version) -replace '[^\d\.]', '').Trim('.')
    if ([version]($gitVer -replace '^(\d+\.\d+).*', '$1') -ge [version]'2.30') { Add-Check 'harness' "git $gitVer" 'OK' }
    else { Add-Check 'harness' "git $gitVer" 'WARN' 'git >= 2.30 recommended' }

    foreach ($repo in Get-HarnessRepoNames) {
        $info = Get-RepoInfo $repo
        if (-not (Test-RepoCloned $repo)) { Add-Check $repo 'cloned' 'FAIL' 'run ./harness.ps1 sync'; continue }
        Add-Check $repo 'cloned' 'OK'

        $url = (Invoke-Git $info.Path @('remote', 'get-url', 'origin')) | Select-Object -First 1
        if ($url -eq $info.RemoteUrl) { Add-Check $repo "origin matches mode '$($info.Mode)'" 'OK' }
        else { Add-Check $repo "origin matches mode '$($info.Mode)'" 'WARN' "origin=$url" }

        $autocrlf = (Invoke-Git $info.Path @('config', '--get', 'core.autocrlf') -AllowFail) | Select-Object -First 1
        if ($autocrlf -eq 'true') { Add-Check $repo 'core.autocrlf' 'WARN' "'true' can make patches fail on CRLF files; see README" }

        foreach ($h in Get-HarnessHookStatus $repo) {
            if ($h.Status -eq 'current') { Add-Check $repo "hook $($h.Hook)" 'OK' }
            else { Add-Check $repo "hook $($h.Hook)" 'FAIL' "$($h.Status); run ./harness.ps1 hooks install $repo" }
        }

        # Patch manifest + state consistency
        foreach ($p in (Get-PatchManifest $repo).patches) {
            if (-not (Test-Path (Get-PatchFilePath $repo $p))) { Add-Check $repo "patch $($p.name)" 'FAIL' 'patch file missing' }
            foreach ($t in $p.targets) {
                if (-not (Get-RefBlob $repo 'HEAD' $t)) { Add-Check $repo "patch $($p.name)" 'FAIL' "target $t not tracked at HEAD" }
            }
        }
        foreach ($s in Get-PatchStatus $repo) {
            $level = if ($s.Dirty) { 'FAIL' } elseif ($s.Drift) { 'WARN' } else { 'OK' }
            $detail = @()
            if ($s.Applied) { $detail += 'applied' } else { $detail += 'not applied' }
            if ($s.Drift) { $detail += "drift: $($s.Drift)" }
            if ($s.Dirty) { $detail += 'target modified beyond patch' }
            Add-Check $repo "patch $($s.Name)" $level ($detail -join '; ')
        }
        $state = Get-PatchState $repo
        $known = @((Get-PatchManifest $repo).patches | ForEach-Object name)
        foreach ($a in $state.applied) {
            if ($known -notcontains $a) { Add-Check $repo 'patch state' 'FAIL' "state lists '$a' which is not in manifest" }
        }
        if (Test-Path (Join-Path (Get-RepoStateDir $repo) 'refresh.pending')) {
            Add-Check $repo 'patch refresh' 'WARN' 'refresh in progress; run patch refresh <repo> <name> -Finish'
        }

        # Overlay
        $ov = @(Get-OverlayStatus $repo)
        $appliedOv = @($ov | Where-Object Status -in 'applied', 'modified')
        foreach ($o in $ov | Where-Object Status -in 'missing', 'modified') {
            Add-Check $repo "overlay $($o.Path)" 'WARN' $o.Status
        }
        $hasBlock = Test-ExcludeBlockPresent $repo
        if ($appliedOv.Count -gt 0 -and -not $hasBlock) { Add-Check $repo 'exclude block' 'FAIL' 'overlay applied but .git/info/exclude block missing' }
        elseif ($appliedOv.Count -eq 0 -and $hasBlock) { Add-Check $repo 'exclude block' 'WARN' 'stale exclude block (no overlay applied)' }
        else { Add-Check $repo 'exclude block' 'OK' }
    }
    $rows
}
