# Tier 3: overlay files. New, untracked, local-only files copied from overlay/<repo>/
# into the clone and hidden via a fenced block in .git/info/exclude.
# Never overwrites a tracked upstream file (that is Tier 4 / patches).

$script:ExcludeBegin = '# >>> aspen-harness overlay (managed; do not edit)'
$script:ExcludeEnd   = '# <<< aspen-harness overlay'

function Get-OverlaySourceFiles([string]$Repo) {
    $dir = Join-Path (Get-HarnessRoot) 'overlay' $Repo
    if (-not (Test-Path $dir)) { return @() }
    @(Get-ChildItem -Path $dir -Recurse -File -Force |
        Where-Object { $_.Name -ne '.gitkeep' } |
        ForEach-Object {
            [pscustomobject]@{
                Rel    = [IO.Path]::GetRelativePath($dir, $_.FullName).Replace('\', '/')
                Source = $_.FullName
            }
        })
}

function Get-OverlayStatePath([string]$Repo) { Join-Path (Get-RepoStateDir $Repo) 'overlay.json' }

function Get-OverlayState([string]$Repo) {
    $s = Read-JsonFile (Get-OverlayStatePath $Repo) @{ files = @() }
    $s.files = @($s.files)
    $s
}

function Set-ExcludeBlock([string]$Repo, [string[]]$RelPaths) {
    $excludeFile = Join-Path (Get-RepoGitDir $Repo) 'info' 'exclude'
    $lines = if (Test-Path $excludeFile) { @(Get-Content $excludeFile) } else { @() }
    $kept = [Collections.Generic.List[string]]::new()
    $inBlock = $false
    foreach ($l in $lines) {
        if ($l -eq $script:ExcludeBegin) { $inBlock = $true; continue }
        if ($l -eq $script:ExcludeEnd) { $inBlock = $false; continue }
        if (-not $inBlock) { $kept.Add($l) }
    }
    while ($kept.Count -gt 0 -and [string]::IsNullOrWhiteSpace($kept[$kept.Count - 1])) { $kept.RemoveAt($kept.Count - 1) }
    if (@($RelPaths).Count -gt 0) {
        if ($kept.Count -gt 0) { $kept.Add('') }
        $kept.Add($script:ExcludeBegin)
        foreach ($r in ($RelPaths | Sort-Object -Unique)) { $kept.Add("/$r") }
        $kept.Add($script:ExcludeEnd)
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $excludeFile -Parent) | Out-Null
    (($kept -join "`n") + "`n") | Set-Content -Path $excludeFile -NoNewline -Encoding utf8
}

function Test-ExcludeBlockPresent([string]$Repo) {
    $excludeFile = Join-Path (Get-RepoGitDir $Repo) 'info' 'exclude'
    (Test-Path $excludeFile) -and (@(Get-Content $excludeFile) -contains $script:ExcludeBegin)
}

function Invoke-OverlayApply([string]$Repo, [switch]$Force) {
    Assert-RepoCloned $Repo
    Write-HStep "overlay apply: $Repo"
    $info = Get-RepoInfo $Repo
    $sources = Get-OverlaySourceFiles $Repo
    if ($sources.Count -eq 0) { Write-HInfo 'no overlay files'; return }

    $state = Get-OverlayState $Repo
    $managed = @{}
    foreach ($f in $state.files) { $managed[$f.path] = $f.sha256 }

    # Pre-flight: all-or-nothing.
    $problems = @()
    foreach ($s in $sources) {
        $tracked = Invoke-Git $info.Path @('ls-files', '--', $s.Rel)
        if (@($tracked).Count -gt 0) { $problems += "$($s.Rel): tracked upstream file (use a patch, not an overlay)"; continue }
        $dest = Join-Path $info.Path $s.Rel
        if (Test-Path $dest) {
            $destHash = Get-FileSha256 $dest
            if (-not $managed.ContainsKey($s.Rel)) {
                if ($destHash -ne (Get-FileSha256 $s.Source) -and -not $Force) {
                    $problems += "$($s.Rel): untracked file exists and is not harness-managed (-Force to overwrite)"
                }
            }
            elseif ($destHash -ne $managed[$s.Rel] -and -not $Force) {
                $problems += "$($s.Rel): locally modified since overlay apply (copy changes back to overlay/, or -Force)"
            }
        }
    }
    if ($problems.Count -gt 0) { Stop-Harness "overlay apply aborted, nothing copied:`n  $($problems -join "`n  ")" }

    $files = @()
    foreach ($s in $sources) {
        $dest = Join-Path $info.Path $s.Rel
        New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
        Copy-Item -Path $s.Source -Destination $dest -Force
        $files += [ordered]@{ path = $s.Rel; sha256 = (Get-FileSha256 $dest) }
    }
    Write-JsonFile (Get-OverlayStatePath $Repo) ([ordered]@{ files = $files; appliedAt = (Get-Date).ToString('o') })
    Set-ExcludeBlock $Repo @($files | ForEach-Object { $_.path })
    Write-HOk "$($files.Count) overlay file(s) applied + excluded"
}

function Invoke-OverlayRemove([string]$Repo) {
    Assert-RepoCloned $Repo
    Write-HStep "overlay remove: $Repo"
    $info = Get-RepoInfo $Repo
    $state = Get-OverlayState $Repo
    $remaining = @()
    $removed = 0
    foreach ($f in $state.files) {
        $dest = Join-Path $info.Path $f.path
        if (-not (Test-Path $dest)) { continue }
        if ((Get-FileSha256 $dest) -eq $f.sha256) {
            Remove-Item $dest -Force
            Remove-EmptyParentDirs $dest $info.Path
            $removed++
        }
        else {
            Write-HWarn "$($f.path) modified locally; kept (still excluded). Copy changes to overlay/ or delete manually."
            $remaining += $f
        }
    }
    $statePath = Get-OverlayStatePath $Repo
    if ($remaining.Count -eq 0) { Remove-Item $statePath -ErrorAction SilentlyContinue }
    else { Write-JsonFile $statePath ([ordered]@{ files = $remaining }) }
    Set-ExcludeBlock $Repo @($remaining | ForEach-Object { $_.path })
    Write-HOk "$removed overlay file(s) removed"
}

function Get-OverlayStatus([string]$Repo) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $state = Get-OverlayState $Repo
    $managed = @{}
    foreach ($f in $state.files) { $managed[$f.path] = $f.sha256 }
    $rels = @(@(Get-OverlaySourceFiles $Repo | ForEach-Object Rel) + @($managed.Keys)) | Sort-Object -Unique
    foreach ($rel in $rels) {
        $dest = Join-Path $info.Path $rel
        $status = if (-not $managed.ContainsKey($rel)) { 'not-applied' }
                  elseif (-not (Test-Path $dest)) { 'missing' }
                  elseif ((Get-FileSha256 $dest) -ne $managed[$rel]) { 'modified' }
                  else { 'applied' }
        [pscustomobject]@{ Repo = $Repo; Path = $rel; Status = $status }
    }
}
