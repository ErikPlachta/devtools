# Tier 1: .NET user-secrets without touching the repo.
# Source : config/<repo>.secrets.local.json  (gitignored; nested JSON, flattened to "A:B" keys)
# Target : user-secrets store for the project's <UserSecretsId>
#          Windows %APPDATA%\Microsoft\UserSecrets\<id>\secrets.json, else ~/.microsoft/usersecrets/<id>/secrets.json
#          (override root with $env:HARNESS_USERSECRETS_ROOT)
# Only keys the harness set are ever changed/removed (tracked in .git/harness/secrets.json).
# Writes the store file directly: no dotnet dependency, and never runs 'user-secrets init' (which edits the csproj).

function Get-SecretsConfig([string]$Repo) {
    $cfg = Get-HarnessConfig
    $r = $cfg.repos[$Repo]
    if (-not $r -or -not $r.ContainsKey('userSecrets') -or -not $r.userSecrets.project) {
        Stop-Harness "no 'userSecrets.project' configured for '$Repo' in harness.json"
    }
    $info = Get-RepoInfo $Repo
    [pscustomobject]@{
        Project    = Join-Path $info.Path $r.userSecrets.project
        SourceFile = Join-Path (Get-HarnessRoot) 'config' "$Repo.secrets.local.json"
    }
}

function Get-UserSecretsId([string]$ProjectPath) {
    if (-not (Test-Path $ProjectPath)) { Stop-Harness "project not found: $ProjectPath" }
    $m = Select-String -Path $ProjectPath -Pattern '<UserSecretsId>\s*([^<\s]+)\s*</UserSecretsId>' | Select-Object -First 1
    if (-not $m) {
        Stop-Harness ("$(Split-Path $ProjectPath -Leaf) has no <UserSecretsId>. 'dotnet user-secrets init' would edit a tracked file.`n" +
            "  Use Tier 1 env vars instead (aspen.code-workspace task/launch 'env', e.g. ConnectionStrings__Aspen),`n" +
            "  or add the id via 'patch new' (Tier 4), or propose it upstream (one-line, harmless).")
    }
    $m.Matches[0].Groups[1].Value
}

function Get-UserSecretsFile([string]$Id) {
    $root = if ($env:HARNESS_USERSECRETS_ROOT) { $env:HARNESS_USERSECRETS_ROOT }
            elseif ($IsWindows) { Join-Path $env:APPDATA 'Microsoft' 'UserSecrets' }
            else { Join-Path $HOME '.microsoft' 'usersecrets' }
    Join-Path $root $Id 'secrets.json'
}

function ConvertTo-FlatSecrets($Node, [string]$Prefix = '') {
    $out = [ordered]@{}
    if ($Node -is [System.Collections.IDictionary]) {
        foreach ($k in $Node.Keys) {
            $key = if ($Prefix) { "${Prefix}:$k" } else { "$k" }
            $child = ConvertTo-FlatSecrets $Node[$k] $key
            foreach ($ck in $child.Keys) { $out[$ck] = $child[$ck] }
        }
    }
    elseif ($Node -is [System.Collections.IList] -and $Node -isnot [string]) {
        for ($i = 0; $i -lt $Node.Count; $i++) {
            $child = ConvertTo-FlatSecrets $Node[$i] "${Prefix}:$i"
            foreach ($ck in $child.Keys) { $out[$ck] = $child[$ck] }
        }
    }
    else { $out[$Prefix] = if ($null -eq $Node) { '' } else { "$Node" } }
    $out
}

function Invoke-SecretsApply([string]$Repo) {
    Assert-RepoCloned $Repo
    Write-HStep "secrets apply: $Repo"
    $sc = Get-SecretsConfig $Repo
    if (-not (Test-Path $sc.SourceFile)) {
        Stop-Harness "missing $($sc.SourceFile) (copy config/$Repo.secrets.example.json to it)"
    }
    $id = Get-UserSecretsId $sc.Project
    $desired = ConvertTo-FlatSecrets (Get-Content -Raw $sc.SourceFile | ConvertFrom-Json -AsHashtable)
    $storeFile = Get-UserSecretsFile $id
    $store = Read-JsonFile $storeFile @{}
    $statePath = Join-Path (Get-RepoStateDir $Repo) 'secrets.json'
    $prev = @((Read-JsonFile $statePath @{ keys = @() }).keys)

    $removed = 0
    foreach ($k in $prev) {
        if (-not $desired.Contains($k) -and $store.ContainsKey($k)) { $store.Remove($k); $removed++ }
    }
    foreach ($k in $desired.Keys) { $store[$k] = $desired[$k] }
    Write-JsonFile $storeFile $store
    Write-JsonFile $statePath ([ordered]@{ userSecretsId = $id; keys = @($desired.Keys) })
    Write-HOk "$(@($desired.Keys).Count) key(s) set, $removed removed -> user-secrets $id"
}

function Get-SecretsStatus([string]$Repo) {
    Assert-RepoCloned $Repo
    $sc = Get-SecretsConfig $Repo
    $id = Get-UserSecretsId $sc.Project
    $store = Read-JsonFile (Get-UserSecretsFile $id) @{}
    $desired = if (Test-Path $sc.SourceFile) { ConvertTo-FlatSecrets (Get-Content -Raw $sc.SourceFile | ConvertFrom-Json -AsHashtable) } else { [ordered]@{} }
    foreach ($k in $desired.Keys) {
        $status = if (-not $store.ContainsKey($k)) { 'not-set' } elseif ("$($store[$k])" -ne $desired[$k]) { 'differs' } else { 'set' }
        $v = $desired[$k]
        $masked = if ($v.Length -le 4) { '****' } else { $v.Substring(0, 2) + ('*' * [Math]::Min(8, $v.Length - 4)) + $v.Substring($v.Length - 2) }
        [pscustomobject]@{ Key = $k; Status = $status; Value = $masked }
    }
}
