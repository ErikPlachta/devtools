# Workflow: sync, up, status, new-feature, ship, clean-check.

function Test-OnlyPatchDirty([string]$Repo) {
    $state = Get-PatchState $Repo
    $dirty = @(Get-DirtyPaths $Repo)
    if ($dirty.Count -eq 0) { return $true }
    foreach ($d in $dirty) {
        if (-not $state.post.ContainsKey($d)) { return $false }
        if ((Get-WorktreeBlob $Repo $d) -ne $state.post[$d]) { return $false }
    }
    $true
}

function Invoke-HarnessSync([string[]]$Repos) {
    if (-not $Repos -or $Repos.Count -eq 0) { $Repos = Get-HarnessRepoNames }
    foreach ($repo in $Repos) {
        $info = Get-RepoInfo $repo
        Write-HStep "sync: $repo  ($($info.Mode): $($info.RemoteUrl))"
        if (-not (Test-RepoCloned $repo)) {
            New-Item -ItemType Directory -Force -Path (Split-Path $info.Path -Parent) | Out-Null
            $cfgArgs = @(foreach ($k in $info.CloneConfig.Keys) { '--config'; "$k=$($info.CloneConfig[$k])" })
            Invoke-Git (Get-HarnessRoot) (@('clone', '--quiet', '--origin', 'origin', '--branch', $info.DefaultBranch) + $cfgArgs + @($info.RemoteUrl, $info.Path)) | Out-Null
            Write-HOk "cloned into $($info.RelPath)"
        }
        else {
            $current = (Invoke-Git $info.Path @('remote', 'get-url', 'origin')) | Select-Object -First 1
            if ($current -ne $info.RemoteUrl) {
                Write-HWarn "origin is '$current' but harness.json ($($info.Mode)) expects '$($info.RemoteUrl)'; fetching anyway"
            }
            Invoke-Git $info.Path @('fetch', '--prune', '--quiet', 'origin') | Out-Null
            $branch = Get-CurrentBranch $repo
            $origin = "origin/$($info.DefaultBranch)"
            if ($branch -ne $info.DefaultBranch) {
                $behind = (Invoke-Git $info.Path @('rev-list', '--count', "HEAD..$origin")) | Select-Object -First 1
                Write-HInfo "on '$branch'; fetched only ($origin is $behind commit(s) ahead of HEAD)"
            }
            elseif (@(Get-DirtyPaths $repo).Count -eq 0) {
                Invoke-Git $info.Path @('merge', '--ff-only', '--quiet', $origin) | Out-Null
                Write-HOk "fast-forwarded $branch"
            }
            elseif (Test-OnlyPatchDirty $repo) {
                Invoke-PatchReset $repo
                Invoke-Git $info.Path @('merge', '--ff-only', '--quiet', $origin) | Out-Null
                Write-HOk "fast-forwarded $branch"
                try { Invoke-PatchApply $repo }
                catch { Write-HWarn "patches NOT re-applied: $($_.Exception.Message)" }
            }
            else {
                Write-HWarn "working tree has non-harness changes; skipped fast-forward"
            }
        }
        Install-HarnessHooks $repo
    }
}

function Invoke-HarnessUp {
    Invoke-HarnessSync
    foreach ($repo in Get-HarnessRepoNames) {
        Invoke-OverlayApply $repo
        try { Invoke-PatchApply $repo } catch { Write-HWarn $_.Exception.Message }
    }
    Write-HStep 'local env ready'
    Write-HInfo "VS Code: open aspen.code-workspace, run task 'aspen: full stack' or F5 'Aspen: Full Stack'"
}

function Get-HarnessStatus {
    foreach ($repo in Get-HarnessRepoNames) {
        $info = Get-RepoInfo $repo
        if (-not (Test-RepoCloned $repo)) {
            [pscustomobject]@{ Repo = $repo; Branch = '(not cloned)'; AheadBehind = ''; Dirty = ''; Patches = ''; Overlay = ''; Hooks = '' }
            continue
        }
        $ab = (Invoke-Git $info.Path @('rev-list', '--left-right', '--count', "HEAD...origin/$($info.DefaultBranch)") -AllowFail) | Select-Object -First 1
        $ab = if ($ab) { $ab -replace '\s+', '/' } else { '?' }
        $patches = @(Get-PatchStatus $repo)
        $applied = @($patches | Where-Object Applied).Count
        $drift = @($patches | Where-Object Drift).Count
        $overlay = @(Get-OverlayStatus $repo)
        $hooks = @(Get-HarnessHookStatus $repo)
        $badHooks = @($hooks | Where-Object Status -ne 'current').Count
        $patchTargets = @((Get-PatchState $repo).post.Keys)
        $userDirty = @(Get-DirtyPaths $repo | Where-Object { $patchTargets -notcontains $_ }).Count
        [pscustomobject]@{
            Repo        = $repo
            Branch      = (Get-CurrentBranch $repo) ?? '(detached)'
            AheadBehind = $ab
            Dirty       = $userDirty
            Patches     = "$applied/$($patches.Count) applied" + $(if ($drift) { ", $drift DRIFT" } else { '' })
            Overlay     = "$(@($overlay | Where-Object Status -eq 'applied').Count)/$($overlay.Count) applied"
            Hooks       = if ($badHooks) { "$badHooks not current" } else { 'ok' }
        }
    }
}

function New-HarnessFeature([string]$Repo, [string]$Name, [string]$Prefix = 'feature/') {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    $branch = "$Prefix$Name"
    Write-HStep "new-feature: $Repo -> $branch"
    Invoke-PatchReset $Repo
    $dirty = @(Get-DirtyPaths $Repo)
    if ($dirty.Count) { Stop-Harness "working tree not clean: $($dirty -join ', ')" }
    Invoke-Git $info.Path @('fetch', '--prune', '--quiet', 'origin') | Out-Null
    Invoke-Git $info.Path @('switch', '--quiet', '--no-track', '-c', $branch, "origin/$($info.DefaultBranch)") | Out-Null
    Write-HOk "on $branch (from origin/$($info.DefaultBranch))"
    Invoke-OverlayApply $Repo
    Invoke-PatchApply $Repo
}

function Invoke-HarnessShip([string]$Repo, [string]$Message, [switch]$All, [switch]$NoPush) {
    Assert-RepoCloned $Repo
    if (-not $Message) { Stop-Harness 'commit message required: ship <repo> -m "message"' }
    $info = Get-RepoInfo $Repo
    $branch = Get-CurrentBranch $Repo
    if ($branch -eq $info.DefaultBranch) { Stop-Harness "refusing to ship from '$branch'; use new-feature first" }
    Write-HStep "ship: $Repo ($branch)"
    $hadPatches = (Get-PatchState $Repo).applied.Count -gt 0
    Invoke-PatchReset $Repo
    try {
        if ($All) { Invoke-Git $info.Path @('add', '--all') | Out-Null }
        $staged = @(Invoke-Git $info.Path @('diff', '--cached', '--name-only'))
        if ($staged.Count -eq 0) { Stop-Harness 'nothing staged (stage files, or pass -All)' }
        Write-HInfo 'committing:'
        $staged | ForEach-Object { Write-HInfo "  $_" }
        $r = Invoke-GitRaw $info.Path @('commit', '--quiet', '-m', $Message)
        if ($r.Err) { $r.Err -split "`n" | ForEach-Object { Write-HInfo $_ } }
        if ($r.Code -ne 0) { Stop-Harness 'commit failed (see hook output above)' }
        if (-not $NoPush) {
            $r = Invoke-GitRaw $info.Path @('push', '--quiet', '-u', 'origin', 'HEAD')
            if ($r.Err) { $r.Err -split "`n" | Where-Object { $_ } | ForEach-Object { Write-HInfo $_ } }
            if ($r.Code -ne 0) { Stop-Harness 'push failed (see output above); commit is local' }
            Write-HOk "pushed $branch"
        }
        else { Write-HOk 'committed (not pushed)' }
    }
    finally {
        if ($hadPatches) {
            try { Invoke-PatchApply $Repo } catch { Write-HWarn "patches not re-applied: $($_.Exception.Message)" }
        }
    }
}

function Invoke-HarnessCleanCheck([string]$Repo) {
    Assert-RepoCloned $Repo
    $info = Get-RepoInfo $Repo
    if (-not $info.CheckCommand) { Stop-Harness "no checkCommand configured for '$Repo' in harness.json" }
    Write-HStep "clean-check: $Repo (patches + overlay removed)"
    $hadPatches = (Get-PatchState $Repo).applied.Count -gt 0
    $hadOverlay = (Get-OverlayState $Repo).files.Count -gt 0
    Invoke-PatchReset $Repo
    Invoke-OverlayRemove $Repo
    $ok = $false
    try {
        Push-Location $info.Path
        try {
            & pwsh -NoProfile -NonInteractive -Command $info.CheckCommand
            $ok = ($LASTEXITCODE -eq 0)
        }
        finally { Pop-Location }
    }
    finally {
        if ($hadOverlay) { Invoke-OverlayApply $Repo }
        if ($hadPatches) { try { Invoke-PatchApply $Repo } catch { Write-HWarn $_.Exception.Message } }
    }
    if ($ok) { Write-HOk 'clean-check passed: branch works without the harness' }
    else { Stop-Harness 'clean-check FAILED without harness env; feature may depend on local config' }
}
