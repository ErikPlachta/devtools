# Aspen local harness module. Dot-sources lib/*.ps1; entry point is ../harness.ps1.
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'

foreach ($f in 'Core', 'Overlay', 'Patch', 'Hooks', 'Workflow', 'Doctor', 'Testbed', 'Secrets', 'Discover') {
    . (Join-Path $PSScriptRoot 'lib' "$f.ps1")
}

Export-ModuleMember -Function *
