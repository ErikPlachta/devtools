var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/api/ping", () => new { status = "ok", env = app.Environment.EnvironmentName });

app.Run();
