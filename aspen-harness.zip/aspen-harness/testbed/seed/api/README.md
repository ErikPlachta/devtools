# aspen-api (TESTBED SEED)

.NET-shaped mock of the Aspen API. Not runnable.
