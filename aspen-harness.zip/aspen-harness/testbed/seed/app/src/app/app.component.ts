import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `<h1>Aspen</h1>`
})
export class AppComponent {}
