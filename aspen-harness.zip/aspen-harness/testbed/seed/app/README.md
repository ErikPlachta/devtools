# aspen-web (TESTBED SEED)

Angular-shaped mock of the Aspen web app. Not runnable.
