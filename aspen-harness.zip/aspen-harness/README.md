# Aspen Local Harness (MVP)

Local-only wrapper workspace around the two Aspen repos (Angular app + .NET API). Your dev env, agent config, run configs and local tweaks live here; the upstream repos stay untouched except for real feature commits.

Design: [docs/aspen-harness-concept.md](docs/aspen-harness-concept.md) · Plan: [docs/aspen-harness-plan.md](docs/aspen-harness-plan.md) · **Next steps: [docs/NEXT-STEPS.md](docs/NEXT-STEPS.md)**

Ships in **testbed mode**: two fake local "remotes" seeded with Angular/.NET-shaped files, so everything runs with no network and no real code.

## Requirements
- PowerShell 7.2+ (`pwsh`), git 2.30+ (Git for Windows provides the `sh` that runs hooks)
- Pester 5.5+ for tests: `Install-Module Pester -MinimumVersion 5.5 -Scope CurrentUser`
- For real use: .NET SDK, Node/Angular CLI, VS Code + C# Dev Kit

## Quickstart (testbed)
```powershell
cd aspen-harness
git init; git add -A; git commit -m "harness MVP"   # version the harness itself (local only)
./harness.ps1 testbed init        # creates .testbed/remote-app.git, remote-api.git
./harness.ps1 up                  # clone, install hooks, apply overlay + patches
./harness.ps1 status
./harness.ps1 doctor
code aspen.code-workspace
```

Feature loop:
```powershell
./harness.ps1 new-feature app reports-page     # branch from origin/main + env applied
# ...write code in repos/app...
./harness.ps1 clean-check app                  # works without harness env?
./harness.ps1 ship app -m "Add reports page" -All
```

Simulate teammates changing files you patch:
```powershell
./harness.ps1 testbed change app target-compatible   # patch still applies; drift flagged
./harness.ps1 testbed change app target-conflict     # patch no longer applies
./harness.ps1 sync app
./harness.ps1 patch refresh app local-dev-server     # resolve markers, then:
./harness.ps1 patch refresh app local-dev-server -Finish
```

## Layout
```
harness.ps1                 CLI
harness.json                repos, remotes per mode (testbed|azdo), cloneConfig, checkCommand
aspen.code-workspace        multi-root: harness + repos/app + repos/api; tasks + launch compound
config/proxy.conf.json      Tier 1: ng serve --proxy-config (passed by CLI, not in the repo)
Directory.Build.props       Tier 2: inherited by repos/api projects (if API has none of its own)
overlay/<repo>/...          Tier 3: local-only new files, copied in + excluded
patches/<repo>/             Tier 4: manifest.json + NNN-name.patch
hooks/guard.ps1             guard logic called by hook shims in repos/*/.git/hooks
scripts/Harness.psm1, lib/  implementation
testbed/                    seed files for fake remotes
tests/Harness.Tests.ps1     Pester suite (35 tests)
config/api.secrets.example.json   template for gitignored config/api.secrets.local.json
AGENTS.md, CLAUDE.md, .github/, .vscode/mcp.json   agent layer
.claude/                    Claude Code: slash commands, permission rules, PreToolUse guard hook
repos/                      clones (gitignored)
```

## Commands
| Command | Does |
|---|---|
| `sync [repo]` | clone or fetch; fast-forward default branch (resets/re-applies patches around it); install hooks |
| `up` | sync + overlay apply + patch apply |
| `status` / `doctor` | summary / invariant checks (exit 1 on FAIL) |
| `new-feature <repo> <name>` | reset patches → clean check → `feature/<name>` from `origin/<default>` → apply env |
| `ship <repo> -m "msg" [-All] [-NoPush]` | reset patches → commit staged (or all) → push `-u` → re-apply patches |
| `clean-check <repo>` | remove env, run `checkCommand`, restore env |
| `overlay apply\|remove\|status [repo]` | Tier 3 |
| `patch apply\|reset\|status [repo]` | Tier 4 |
| `patch new <repo> <name> <file...>` | capture current working-tree edits of tracked files as a patch |
| `patch refresh <repo> <name> [-Finish]` | rebase a patch on current upstream (3-way) |
| `patch retire <repo> <name>` | delete a patch no longer needed |
| `hooks install\|status\|uninstall [repo]` | (re)install guard hooks (takes over `core.hooksPath` if set); uninstall restores prior hooks |
| `secrets apply\|status <repo>` | Tier 1: `config/<repo>.secrets.local.json` → .NET user-secrets store (values masked in status) |
| `discover <repo> [-Path <clone>] [-Out <md>]` | Phase 0: risks + tier suggestion per local edit; point `-Path` at your current working copy |
| `testbed init [-Force]` / `testbed change <repo> <scenario>` | fake remotes / simulated upstream commits |

## Patch framework in one paragraph
Edit a tracked file in a clone (e.g. `angular.json` port) → `patch new app local-dev-server angular.json` saves the diff to `patches/app/` and records the upstream blob it was made against. `patch reset` removes all patches (refuses if you edited a target beyond the patch); `patch apply` re-applies them all or none. If upstream later changes that file, `status`/`doctor`/post-merge hook report drift; if the patch no longer applies, `patch refresh` does a 3-way apply so you resolve once and regenerate.

## Guardrails
- **pre-commit**: blocks staged patch targets and overlay paths. Bypass for genuine upstream edits: `HARNESS_ALLOW_PATCHED=1 git commit ...` (logged to `.git/harness/bypass.log` by **post-commit**).
- **pre-push**: re-checks every outgoing commit; blocks protected paths without a logged bypass (catches `--no-verify`).
- **post-checkout / post-merge**: warn on drift.
- Hooks chain any pre-existing hook (`<name>.chained`); missing `pwsh` fails closed for `pre-*`.
- Overlay never overwrites tracked files or unmanaged untracked files; removes only unmodified files it placed.
- `doctor`: hooks current, state ↔ worktree consistency, exclude block, manifest targets tracked, autocrlf.

## Cutover to the real repos (Phase 9)
1. Phase 0: `./harness.ps1 discover app -Path <your current app clone> -Out docs/discovery/app.md` (same for api). Review tiers; check the Risks section first.
2. `harness.json`: set real `remotes.azdo` URLs, `defaultBranch`, real `checkCommand`s (`npm ci; npx ng build`, `dotnet build; dotnet test`), then `"mode": "azdo"`.
3. `patch retire` the two testbed example patches; delete testbed overlay examples you don't want.
4. `Remove-Item -Recurse repos; ./harness.ps1 up`, then recreate your real patches with `patch new`.
5. Run one trivial feature through `new-feature` → `clean-check` → `ship`.

## Known limitations / gotchas
- **`core.hooksPath` (husky etc.)**: handled by local takeover (clone's local config → `.git/harness/hooks`, chaining to husky). `npm install` re-running husky's `prepare` resets it: guardrails are OFF until `sync`/`hooks install`; `doctor` reports it as FAIL. Run `doctor` after `npm ci`.
- **`.npmrc`**: npm never reads a parent-directory `.npmrc` (earlier docs said Tier 2; corrected). Use `~/.npmrc` or `NPM_CONFIG_*`.
- **Claude Code permission rules aren't a security boundary** (`git -C x push` evades `Bash(git push *)`). The git hooks are the enforcement; `.claude/` rules + hook are a first line.
- **Line endings**: `git apply` can fail on CRLF worktrees with `core.autocrlf=true`. Clones are created with `cloneConfig` (`core.autocrlf=input`); doctor warns on `true`. Harness `.gitattributes` keeps `*.patch` binary-safe.
- **Testbed seeds aren't runnable**: workspace tasks/launch target the real stack; in testbed mode only harness commands do anything.
- `ship -All` stages everything not ignored/excluded; review the printed file list (patch targets are reset first, overlay files are excluded).
- Hook shims embed the absolute harness path; moving the harness → `./harness.ps1 hooks install`.
- Single-user, single-machine design. No locking.

## MVP coverage vs plan
| Phase | Status |
|---|---|
| 0 Discovery | tool done (`discover`); **run it against your real working copies** |
| 1 Testbed | done (`testbed init/change`, 3 scenarios/repo) |
| 2 Skeleton | done |
| 3 Run & debug | framed (tasks/launch/compound written; untested against real stack) |
| 4 Tier 1–2 | done/framed (`secrets apply`, `config/proxy.conf.json`, env vars in workspace, `Directory.Build.props`) |
| 5 Overlay | done |
| 6 Patches + guardrails | done (apply/reset/status/new/refresh/retire, 5 hooks, chaining, husky takeover, uninstall, doctor, tests) |
| 7 Workflow | done (`new-feature`, `ship`, `clean-check`, `up`, `status`) |
| 8 Agent layer | done/framed (AGENTS.md, CLAUDE.md, `.claude/` commands + permissions + guard hook; Copilot instructions; mcp.json — verify MCP packages) |
| 9 Cutover | todo |
| 10 Upstream local-override PR | todo |
