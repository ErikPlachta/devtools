#!/usr/bin/env pwsh
# Aspen local harness CLI. Run from anywhere: ./harness.ps1 <command> [args] [-flags]
# Intentionally a non-advanced script so unknown -flags land in $args for the parser below.
param([string]$Command = 'help')

$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'scripts' 'Harness.psm1') -Force -DisableNameChecking

# --- tiny arg parser: positionals + flags (value flags take the next token) ---
$valueFlags = @('m', 'message', 'reason', 'retirewhen', 'prefix', 'path', 'out')
$pos = [Collections.Generic.List[string]]::new()
$flags = @{}
for ($i = 0; $i -lt $args.Count; $i++) {
    $a = [string]$args[$i]
    if ($a -match '^--?([A-Za-z][\w-]*)$') {
        $k = $Matches[1].ToLowerInvariant()
        if ($valueFlags -contains $k) {
            if ($i + 1 -ge $args.Count) { throw "flag -$k needs a value" }
            $flags[$k] = [string]$args[++$i]
        }
        else { $flags[$k] = $true }
    }
    else { $pos.Add($a) }
}
function Arg([int]$n, [string]$what) {
    if ($pos.Count -le $n) { throw "missing argument: $what (see ./harness.ps1 help)" }
    $pos[$n]
}
function Repos-Or-All([int]$from) {
    if ($pos.Count -gt $from) { @($pos | Select-Object -Skip $from) } else { Get-HarnessRepoNames }
}

$help = @'
Aspen local harness

  sync [repo...]                 clone/fetch, fast-forward default branch, install hooks
  up                             sync + overlay apply + patch apply (full local env)
  status                         one-screen view of both repos
  doctor                         verify invariants (exit 1 on FAIL)

  new-feature <repo> <name>      branch feature/<name> from origin/<default>, apply env
  ship <repo> -m "msg" [-All] [-NoPush]
                                 reset patches -> commit -> push -> re-apply patches
  clean-check <repo>             run checkCommand with patches + overlay removed

  overlay apply|remove|status [repo]      [-Force]
  patch apply|reset|status [repo]
  patch new <repo> <name> <file...>       [-Reason "..."] [-RetireWhen "..."]
  patch refresh <repo> <name>             [-Finish]
  patch retire <repo> <name>
  hooks install|status|uninstall [repo]  (uninstall = guardrails off, restores prior hooks/hooksPath)
  secrets apply|status <repo>            Tier 1: config/<repo>.secrets.local.json -> dotnet user-secrets store
  discover <repo> [-Path <existing clone>] [-Out <file.md>]
                                          Phase 0: risks + tier suggestions for current local edits

  testbed init [-Force]                   create local fake remotes (.testbed/)
  testbed change <repo> <scenario>        simulate upstream commit
                                          scenarios: unrelated | target-compatible | target-conflict
'@

try {
    switch ($Command.ToLowerInvariant()) {
        'help'        { $help }
        'sync'        { Invoke-HarnessSync (Repos-Or-All 0) }
        'up'          { Invoke-HarnessUp }
        'status'      { Get-HarnessStatus | Format-Table -AutoSize | Out-String -Width 200 | Write-Host }
        'doctor'      {
            $rows = @(Invoke-HarnessDoctor)
            $rows | Format-Table Level, Scope, Check, Detail -AutoSize -Wrap | Out-String -Width 200 | Write-Host
            $fails = @($rows | Where-Object Level -eq 'FAIL').Count
            if ($fails) { Write-Host "doctor: $fails FAIL" -ForegroundColor Red; exit 1 }
            Write-Host 'doctor: healthy' -ForegroundColor Green
        }
        'new-feature' { New-HarnessFeature (Arg 0 'repo') (Arg 1 'name') ($flags['prefix'] ?? 'feature/') }
        'ship'        {
            $msg = $flags['m'] ?? $flags['message']
            Invoke-HarnessShip (Arg 0 'repo') $msg -All:([bool]$flags['all']) -NoPush:([bool]$flags['nopush'])
        }
        'clean-check' { Invoke-HarnessCleanCheck (Arg 0 'repo') }
        'overlay'     {
            $sub = Arg 0 'apply|remove|status'
            foreach ($r in (Repos-Or-All 1)) {
                switch ($sub) {
                    'apply'  { Invoke-OverlayApply $r -Force:([bool]$flags['force']) }
                    'remove' { Invoke-OverlayRemove $r }
                    'status' { Get-OverlayStatus $r | Format-Table -AutoSize | Out-String -Width 200 | Write-Host }
                    default  { throw "unknown overlay subcommand '$sub'" }
                }
            }
        }
        'patch'       {
            $sub = Arg 0 'apply|reset|status|new|refresh|retire'
            switch ($sub) {
                'apply'   { foreach ($r in (Repos-Or-All 1)) { Invoke-PatchApply $r } }
                'reset'   { foreach ($r in (Repos-Or-All 1)) { Invoke-PatchReset $r } }
                'status'  { foreach ($r in (Repos-Or-All 1)) { Get-PatchStatus $r | Format-Table -AutoSize | Out-String -Width 200 | Write-Host } }
                'new'     {
                    $targets = @($pos | Select-Object -Skip 3)
                    New-HarnessPatch (Arg 1 'repo') (Arg 2 'name') $targets ($flags['reason'] ?? '') ($flags['retirewhen'] ?? '')
                }
                'refresh' { Invoke-PatchRefresh (Arg 1 'repo') (Arg 2 'name') -Finish:([bool]$flags['finish']) }
                'retire'  { Remove-HarnessPatch (Arg 1 'repo') (Arg 2 'name') }
                default   { throw "unknown patch subcommand '$sub'" }
            }
        }
        'hooks'       {
            $sub = Arg 0 'install|status'
            foreach ($r in (Repos-Or-All 1)) {
                switch ($sub) {
                    'install' { Install-HarnessHooks $r }
                    'status'    { Get-HarnessHookStatus $r | Format-Table -AutoSize | Out-String -Width 200 | Write-Host }
                    'uninstall' { Uninstall-HarnessHooks $r }
                    default     { throw "unknown hooks subcommand '$sub'" }
                }
            }
        }
        'secrets'     {
            $sub = Arg 0 'apply|status'
            switch ($sub) {
                'apply'  { Invoke-SecretsApply (Arg 1 'repo') }
                'status' { Get-SecretsStatus (Arg 1 'repo') | Format-Table -AutoSize | Out-String -Width 200 | Write-Host }
                default  { throw "unknown secrets subcommand '$sub'" }
            }
        }
        'discover'    {
            $report = Invoke-HarnessDiscover (Arg 0 'repo') ($flags['path'] ?? '')
            if ($flags['out']) {
                $report | Set-Content -Path $flags['out'] -Encoding utf8
                Write-Host "report written: $($flags['out'])" -ForegroundColor Green
            }
            else { $report }
        }
        'testbed'     {
            $sub = Arg 0 'init|change'
            switch ($sub) {
                'init'   { Initialize-Testbed -Force:([bool]$flags['force']) }
                'change' { Invoke-UpstreamChange (Arg 1 'repo') (Arg 2 'scenario') }
                default  { throw "unknown testbed subcommand '$sub'" }
            }
        }
        default       { throw "unknown command '$Command'`n$help" }
    }
}
catch {
    Write-Host "error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
