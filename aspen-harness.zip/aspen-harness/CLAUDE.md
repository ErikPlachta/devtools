@AGENTS.md

# Claude Code — harness development notes

You are working on the harness itself (PowerShell 7 tooling) unless the user says they're doing feature work in `repos/*`.

## Design docs
- `docs/aspen-harness-concept.md` — why/what (tiers, guardrails, risks)
- `docs/aspen-harness-plan.md` — phased plan with exit criteria

## Code map
- `harness.ps1` — CLI entry + arg parser (non-advanced script on purpose: unknown `-flags` land in `$args`)
- `scripts/Harness.psm1` — module; dot-sources `scripts/lib/*.ps1`
  - `Core.ps1` config (`harness.json`), git wrapper (`Invoke-Git`/`Invoke-GitRaw`), JSON/state helpers
  - `Overlay.ps1` Tier 3 (copy + `.git/info/exclude` fenced block, state in `.git/harness/overlay.json`)
  - `Patch.ps1` Tier 4 (manifest, transactional apply/reset, drift via baseBlobs, refresh via `git apply --3way`)
  - `Hooks.ps1` hook installer (default: chains existing hooks as `<name>.chained`; takeover: local `core.hooksPath` → `.git/harness/hooks`, chains husky) + uninstall + guard logic
  - `Workflow.ps1` sync / up / status / new-feature / ship / clean-check
  - `Doctor.ps1` invariant checks
  - `Testbed.ps1` fake bare remotes + simulated upstream commits
  - `Secrets.ps1` Tier 1 user-secrets (writes store file directly; never `user-secrets init`)
  - `Discover.ps1` Phase 0 report (risks + tier suggestions), read-only
- `hooks/guard.ps1` — invoked by the sh shims in `repos/*/.git/hooks`
- Per-clone state lives in `repos/<repo>/.git/harness/` (patches.json, overlay.json, hooks.json, secrets.json, bypass.log, refresh.pending; takeover hooks in `hooks/`)
- `.claude/` — slash commands (`/new-feature`, `/ship`, `/patch-capture`, `/patch-refresh`, `/discover`), permission rules, and a PreToolUse hook (`.claude/hooks/guard-shell.ps1`) that escalates guardrail bypasses (env-var prefixes permission rules can't see) to an explicit prompt

## Conventions
- PowerShell 7+, `Set-StrictMode -Version 3.0`, `$ErrorActionPreference = 'Stop'`.
- Errors: `Stop-Harness "msg"` (throws; CLI prints + exit 1). Output via `Write-HStep/HOk/HWarn/HInfo`.
- Always wrap pipeline results in `@()` before `.Count` or `+` (single-item results are scalars; string + array concatenates).
- Don't name helpers `H`/`G` etc.: aliases win over functions (`h` = Get-History).
- Git calls go through `Invoke-Git`/`Invoke-GitRaw`; never parse porcelain v2 ad hoc elsewhere.
- Any operation touching a clone must be all-or-nothing or roll back.

## Testing
- `Invoke-Pester ./tests` (Pester 5.5+). Each `Describe` copies the harness to temp and builds a fresh testbed; nothing touches `repos/` here.
- Manual loop: `./harness.ps1 testbed init -Force; Remove-Item -Recurse -Force repos; ./harness.ps1 up`
- Simulate teammates: `./harness.ps1 testbed change app target-conflict` then `sync app`.

## Status vs plan
See README "MVP coverage".

## Next steps
@docs/NEXT-STEPS.md

When starting a session with no specific task, resume at the first unchecked step in `docs/NEXT-STEPS.md` and tell the user which step you're on.
