# Pester 5 tests. Each Describe gets a throwaway copy of the harness + fresh testbed.
# Run:  Invoke-Pester ./tests        (Install-Module Pester -MinimumVersion 5.5 -Scope CurrentUser)

BeforeAll {
    $script:SourceRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
    $env:GIT_AUTHOR_NAME = 'Harness Test'; $env:GIT_AUTHOR_EMAIL = 'test@harness.local'
    $env:GIT_COMMITTER_NAME = 'Harness Test'; $env:GIT_COMMITTER_EMAIL = 'test@harness.local'
    Remove-Item Env:HARNESS_ALLOW_PATCHED -ErrorAction SilentlyContinue

    function New-TestHarness {
        $dest = Join-Path ([IO.Path]::GetTempPath()) ("aspen-harness-test-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
        New-Item -ItemType Directory -Path $dest | Out-Null
        Get-ChildItem -Force $script:SourceRoot |
            Where-Object { $_.Name -notin 'repos', '.testbed', '.git' } |
            Copy-Item -Destination $dest -Recurse -Force
        $script:Root = $dest
        Harness testbed init | Out-Null
        Harness sync | Out-Null
        $dest
    }

    # Run the CLI in a subprocess (named Harness: 'H' is the Get-History alias); returns @{ Code; Out }.
    function Harness {
        $out = & pwsh -NoProfile -NonInteractive -File (Join-Path $script:Root 'harness.ps1') @args 2>&1 | Out-String
        @{ Code = $LASTEXITCODE; Out = $out }
    }

    function RepoGit([string]$Repo) {
        $r = & git -C (Join-Path $script:Root 'repos' $Repo) @args 2>&1 | Out-String
        @{ Code = $LASTEXITCODE; Out = $r.Trim() }
    }

    function RepoFile([string]$Repo, [string]$Rel) { Join-Path $script:Root 'repos' $Repo $Rel }
    function Hash([string]$Path) { (Get-FileHash -Algorithm SHA256 $Path).Hash }
    function Remove-TestHarness { if ($script:Root -and (Test-Path $script:Root)) { Remove-Item $script:Root -Recurse -Force } }
}

Describe 'sync' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'clones both repos' {
        Test-Path (RepoFile 'app' '.git') | Should -BeTrue
        Test-Path (RepoFile 'api' '.git') | Should -BeTrue
    }
    It 'installs guard hooks' {
        Get-Content -Raw (RepoFile 'app' '.git/hooks/pre-commit') | Should -Match 'aspen-harness-hook'
    }
    It 'leaves clones clean' {
        (RepoGit 'app' status --porcelain).Out | Should -BeNullOrEmpty
    }
    It 'doctor is healthy' {
        (Harness doctor).Code | Should -Be 0
    }
}

Describe 'overlay (tier 3)' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'applies files invisibly to git' {
        (Harness overlay apply api).Code | Should -Be 0
        Test-Path (RepoFile 'api' 'http/aspen-api.http') | Should -BeTrue
        (RepoGit 'api' status --porcelain).Out | Should -BeNullOrEmpty
    }
    It 'removes only what it placed' {
        (Harness overlay remove api).Code | Should -Be 0
        Test-Path (RepoFile 'api' 'http') | Should -BeFalse
        Get-Content -Raw (RepoFile 'api' '.git/info/exclude') | Should -Not -Match 'aspen-harness overlay'
    }
    It 'refuses to shadow a tracked upstream file' {
        $bad = Join-Path $script:Root 'overlay/api/README.md'
        Set-Content $bad 'shadow'
        try {
            $r = Harness overlay apply api
            $r.Code | Should -Be 1
            $r.Out | Should -Match 'tracked upstream file'
            Test-Path (RepoFile 'api' 'http/aspen-api.http') | Should -BeFalse   # all-or-nothing
        }
        finally { Remove-Item $bad }
    }
}

Describe 'patch apply/reset (tier 4)' {
    BeforeAll {
        New-TestHarness | Out-Null
        $script:Original = Hash (RepoFile 'app' 'angular.json')
    }
    AfterAll { Remove-TestHarness }

    It 'applies and records state' {
        (Harness patch apply app).Code | Should -Be 0
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '"port": 4300'
        Test-Path (RepoFile 'app' '.git/harness/patches.json') | Should -BeTrue
    }
    It 'apply is idempotent' {
        (Harness patch apply app).Out | Should -Match 'already applied'
    }
    It 'reset restores byte-identical upstream file' {
        (Harness patch reset app).Code | Should -Be 0
        Hash (RepoFile 'app' 'angular.json') | Should -Be $script:Original
        (RepoGit 'app' status --porcelain).Out | Should -BeNullOrEmpty
    }
    It 'reset refuses when target modified beyond the patch' {
        Harness patch apply app | Out-Null
        Add-Content (RepoFile 'app' 'angular.json') ' '
        $r = Harness patch reset app
        $r.Code | Should -Be 1
        $r.Out | Should -Match 'modified beyond the patch'
    }
}

Describe 'patch all-or-nothing' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'rolls back earlier patches when a later one fails' {
        $dir = Join-Path $script:Root 'patches/app'
        $m = Get-Content -Raw "$dir/manifest.json" | ConvertFrom-Json -AsHashtable
        @"
diff --git a/package.json b/package.json
--- a/package.json
+++ b/package.json
@@ -1,3 +1,3 @@
 {
-  "name": "does-not-match",
+  "name": "broken",
   "version": "0.0.0",
"@ | Set-Content "$dir/999-broken.patch" -NoNewline
        $m.patches = @($m.patches) + @{ name = 'broken'; file = '999-broken.patch'; targets = @('package.json'); baseBlobs = @{ 'package.json' = 'x' } }
        $m | ConvertTo-Json -Depth 10 | Set-Content "$dir/manifest.json"

        $r = Harness patch apply app
        $r.Code | Should -Be 1
        $r.Out | Should -Match 'Rolled back 1'
        (RepoGit 'app' status --porcelain).Out | Should -BeNullOrEmpty
    }
}

Describe 'drift + refresh' {
    BeforeAll {
        New-TestHarness | Out-Null
        Harness patch apply app | Out-Null
    }
    AfterAll { Remove-TestHarness }

    It 'compatible upstream change: sync re-applies, flags drift' {
        Harness testbed change app target-compatible | Out-Null
        (Harness sync app).Out | Should -Match 'drift'
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '"port": 4300'
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '750kb'
    }
    It 'conflicting upstream change: patches left unapplied, loudly' {
        Harness testbed change app target-conflict | Out-Null
        (Harness sync app).Out | Should -Match 'patches NOT re-applied'
        (RepoGit 'app' status --porcelain).Out | Should -BeNullOrEmpty
        (Harness patch apply app).Code | Should -Be 1
    }
    It 'refresh -> resolve -> finish rebases the patch' {
        (Harness patch refresh app local-dev-server).Out | Should -Match 'conflicts'
        $f = RepoFile 'app' 'angular.json'
        $resolved = (Get-Content -Raw $f) -replace '(?s)<<<<<<< ours\r?\n.*?=======\r?\n(.*?)>>>>>>> theirs\r?\n', '$1'
        Set-Content $f $resolved -NoNewline
        (Harness patch refresh app local-dev-server -Finish).Code | Should -Be 0
        (Harness patch reset app).Code | Should -Be 0
        (Harness patch apply app).Code | Should -Be 0
        (Harness patch status app).Out | Should -Not -Match 'HEAD:angular.json'
    }
}

Describe 'guard hooks' {
    BeforeAll {
        New-TestHarness | Out-Null
        Harness patch apply app | Out-Null
    }
    AfterAll { Remove-TestHarness; Remove-Item Env:HARNESS_ALLOW_PATCHED -ErrorAction SilentlyContinue }

    It 'pre-commit blocks a staged patch target' {
        RepoGit 'app' add angular.json | Out-Null
        $r = RepoGit 'app' commit -m 'oops'
        $r.Code | Should -Not -Be 0
        $r.Out | Should -Match 'commit blocked'
        RepoGit 'app' restore --staged angular.json | Out-Null
    }
    It 'bypass commits and logs the commit id' {
        Harness patch reset app | Out-Null
        $f = RepoFile 'app' 'angular.json'
        (Get-Content -Raw $f).Replace('"1mb"', '"2mb"') | Set-Content $f -NoNewline
        RepoGit 'app' add angular.json | Out-Null
        $env:HARNESS_ALLOW_PATCHED = '1'
        (RepoGit 'app' commit -m 'legit budget change').Code | Should -Be 0
        Remove-Item Env:HARNESS_ALLOW_PATCHED
        $head = (RepoGit 'app' rev-parse HEAD).Out
        Get-Content -Raw (RepoFile 'app' '.git/harness/bypass.log') | Should -Match $head
    }
    It 'pre-push allows logged bypass commits' {
        (RepoGit 'app' push origin HEAD:refs/heads/test-ok).Code | Should -Be 0
    }
    It 'pre-push blocks unlogged commits touching protected paths (--no-verify)' {
        $f = RepoFile 'app' 'angular.json'
        (Get-Content -Raw $f).Replace('"2mb"', '"3mb"') | Set-Content $f -NoNewline
        RepoGit 'app' commit --no-verify -am 'sneaky' | Out-Null
        $r = RepoGit 'app' push origin HEAD:refs/heads/test-bad
        $r.Code | Should -Not -Be 0
        $r.Out | Should -Match 'push blocked'
    }
}

Describe 'hook chaining' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'preserves and runs a pre-existing hook' {
        $hook = RepoFile 'api' '.git/hooks/pre-commit'
        $marker = Join-Path $script:Root 'chained-ran.txt'
        Set-Content $hook "#!/bin/sh`necho ran > '$($marker -replace '\\','/')'`n" -NoNewline
        if (-not $IsWindows) { & chmod +x $hook }
        (Harness hooks install api).Out | Should -Match 'preserved'
        Test-Path "$hook.chained" | Should -BeTrue
        Set-Content (RepoFile 'api' 'NEW.md') 'x'
        RepoGit 'api' add NEW.md | Out-Null
        (RepoGit 'api' commit -m 'add file').Code | Should -Be 0
        Test-Path $marker | Should -BeTrue
    }
}

Describe 'feature workflow' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'new-feature branches from origin and applies env' {
        (Harness new-feature app reports).Code | Should -Be 0
        (RepoGit 'app' branch --show-current).Out | Should -Be 'feature/reports'
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '"port": 4300'
        Test-Path (RepoFile 'app' '.github/copilot-instructions.md') | Should -BeTrue
    }
    It 'ship pushes feature-only commit and re-applies patches' {
        Set-Content (RepoFile 'app' 'src/app/reports.ts') 'export const reports = true;'
        (Harness ship app -m 'Add reports' -All).Code | Should -Be 0
        $files = & git --git-dir (Join-Path $script:Root '.testbed/remote-app.git') show --name-only --format= feature/reports
        @($files) | Should -Be @('src/app/reports.ts')
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '"port": 4300'
    }
    It 'ship refuses on the default branch' {
        RepoGit 'app' switch main | Out-Null
        (Harness ship app -m 'x' -All).Code | Should -Be 1
    }
    It 'clean-check runs without env and restores it' {
        RepoGit 'app' switch feature/reports | Out-Null
        (Harness clean-check app).Code | Should -Be 0
        Get-Content -Raw (RepoFile 'app' 'angular.json') | Should -Match '"port": 4300'
    }
}

Describe 'doctor' {
    BeforeAll { New-TestHarness | Out-Null }
    AfterAll { Remove-TestHarness }

    It 'fails when a hook is missing' {
        Remove-Item (RepoFile 'app' '.git/hooks/pre-push')
        $r = Harness doctor
        $r.Code | Should -Be 1
        $r.Out | Should -Match 'missing'
    }
}

Describe 'core.hooksPath takeover (husky)' {
    BeforeAll {
        New-TestHarness | Out-Null
        Harness patch apply app | Out-Null
        $script:HuskyDir = RepoFile 'app' '.husky/_'
        New-Item -ItemType Directory -Force -Path $script:HuskyDir | Out-Null
        $script:HuskyMarker = Join-Path $script:Root 'husky-ran.txt'
        Set-Content (Join-Path $script:HuskyDir 'pre-commit') "#!/bin/sh`necho ran > '$($script:HuskyMarker -replace '\\','/')'`n" -NoNewline
        if (-not $IsWindows) { & chmod +x (Join-Path $script:HuskyDir 'pre-commit') }
        Add-Content (RepoFile 'app' '.git/info/exclude') '/.husky/'
        RepoGit 'app' config core.hooksPath .husky/_ | Out-Null
    }
    AfterAll { Remove-TestHarness }

    It 'doctor flags a foreign hooksPath' {
        (Harness doctor).Code | Should -Be 1
    }
    It 'install takes over locally and records the original' {
        (Harness hooks install app).Out | Should -Match 'takeover'
        (RepoGit 'app' config core.hooksPath).Out | Should -Match '\.git/harness/hooks$'
        Get-Content -Raw (RepoFile 'app' '.git/harness/hooks.json') | Should -Match '\.husky/_'
    }
    It 'chains to husky and still guards' {
        Set-Content (RepoFile 'app' 'src/app/y.ts') 'export const y = 1;'
        RepoGit 'app' add src/app/y.ts | Out-Null
        (RepoGit 'app' commit -m 'feature y').Code | Should -Be 0
        Test-Path $script:HuskyMarker | Should -BeTrue
        RepoGit 'app' add angular.json | Out-Null
        (RepoGit 'app' commit -m 'bad').Out | Should -Match 'commit blocked'
        RepoGit 'app' restore --staged angular.json | Out-Null
    }
    It 'detects husky resetting hooksPath and re-takes on install' {
        RepoGit 'app' config core.hooksPath .husky/_ | Out-Null
        (Harness hooks status app).Out | Should -Match 'hooksPath-reset'
        (Harness hooks install app).Out | Should -Match 'taking over again'
        (Harness doctor).Code | Should -Be 0
    }
    It 'uninstall restores the original hooksPath' {
        (Harness hooks uninstall app).Code | Should -Be 0
        (RepoGit 'app' config core.hooksPath).Out | Should -Be '.husky/_'
    }
}

Describe 'secrets (tier 1)' {
    BeforeAll {
        New-TestHarness | Out-Null
        $env:HARNESS_USERSECRETS_ROOT = Join-Path $script:Root 'usersecrets'
        Copy-Item (Join-Path $script:Root 'config/api.secrets.example.json') (Join-Path $script:Root 'config/api.secrets.local.json')
    }
    AfterAll { Remove-TestHarness; Remove-Item Env:HARNESS_USERSECRETS_ROOT -ErrorAction SilentlyContinue }

    It 'writes flattened keys to the user-secrets store without touching the repo' {
        (Harness secrets apply api).Code | Should -Be 0
        $store = Get-Content -Raw (Join-Path $env:HARNESS_USERSECRETS_ROOT 'aspen-api-3f2b9c4e-testbed/secrets.json') | ConvertFrom-Json -AsHashtable
        $store['ExternalApis:Pricing:ApiKey'] | Should -Be 'replace-me'
        (RepoGit 'api' status --porcelain).Out | Should -BeNullOrEmpty
    }
    It 'removes keys it set when dropped from the local file, keeps foreign keys' {
        $storeFile = Join-Path $env:HARNESS_USERSECRETS_ROOT 'aspen-api-3f2b9c4e-testbed/secrets.json'
        $s = Get-Content -Raw $storeFile | ConvertFrom-Json -AsHashtable
        $s['Mine:Manual'] = 'keep'
        $s | ConvertTo-Json | Set-Content $storeFile
        '{ "ConnectionStrings": { "Aspen": "x" } }' | Set-Content (Join-Path $script:Root 'config/api.secrets.local.json')
        (Harness secrets apply api).Out | Should -Match '1 removed'
        $s = Get-Content -Raw $storeFile | ConvertFrom-Json -AsHashtable
        $s.ContainsKey('ExternalApis:Pricing:ApiKey') | Should -BeFalse
        $s['Mine:Manual'] | Should -Be 'keep'
    }
    It 'refuses when the project has no UserSecretsId' {
        $csproj = RepoFile 'api' 'src/Aspen.Api/Aspen.Api.csproj'
        (Get-Content -Raw $csproj) -replace '\s*<UserSecretsId>.*</UserSecretsId>', '' | Set-Content $csproj -NoNewline
        $r = Harness secrets apply api
        $r.Code | Should -Be 1
        $r.Out | Should -Match 'no <UserSecretsId>'
        RepoGit 'api' checkout -- . | Out-Null
    }
}

Describe 'discover (phase 0)' {
    BeforeAll {
        New-TestHarness | Out-Null
        Harness up | Out-Null
        $f = RepoFile 'api' 'src/Aspen.Api/appsettings.json'
        (Get-Content -Raw $f).Replace('shared-dev-sql', 'localhost') | Set-Content $f -NoNewline
        Set-Content (RepoFile 'api' 'scratch.sql') 'select 1'
    }
    AfterAll { Remove-TestHarness }

    It 'suggests tiers for local edits and labels managed paths' {
        $r = Harness discover api
        $r.Code | Should -Be 0
        $r.Out | Should -Match 'appsettings\.json.*\| 1 \|'
        $r.Out | Should -Match 'scratch\.sql.*\| 3 \|'
        $r.Out | Should -Match "launchSettings\.json.*managed.*local-launch-profile"
    }
    It 'scans an external working copy with -Path and writes -Out' {
        $ext = Join-Path $script:Root 'external-copy'
        & git clone -q (Join-Path $script:Root '.testbed/remote-app.git') $ext
        Set-Content (Join-Path $ext 'package.json') '{ "name": "x", "scripts": { "prepare": "husky" } }'
        $out = Join-Path $script:Root 'disc.md'
        (Harness discover app -Path $ext -Out $out).Code | Should -Be 0
        Get-Content -Raw $out | Should -Match 'existing working copy'
        Get-Content -Raw $out | Should -Match '\*\*Hooks:\*\*'
    }
}
