# Next Steps — Agent Runbook

Ordered checklist for taking the harness from testbed MVP to daily use on the real Aspen repos.
Work top to bottom. Don't start a step until the previous step's **Done when** holds.

**Legend**
- **[agent]**: the agent can do the whole step.
- **[user]**: needs the user: a path, URL, credential, decision, or approval. Ask with one concise question, then wait.
- **[agent+user]**: agent prepares, user approves before anything changes.

**Standing rules** (on top of `AGENTS.md`):
- Never run anything that writes to an upstream remote (push, `ship`) without explicit user approval in that turn ("yes, ship it" / "yes, push"). Implied consent doesn't count.
- Never modify the user's existing working copies (the ones scanned in Phase 0). Read-only.
- Never read or print `config/*.secrets.local.json` values.
- If a step fails, stop, report the exact error and your diagnosis, and propose a fix. Don't improvise around the guardrails.
- After finishing a step, tick its box here (`- [x]`) and add a one-line note under **Log** at the bottom with the date and outcome. Committing that edit to the *harness* repo is fine.

---

## Step 1: Validate the MVP on this machine  [agent]

- [ ] Check prerequisites: `pwsh -v` (≥ 7.2), `git --version` (≥ 2.30), `Get-Module Pester -ListAvailable` (≥ 5.5). If Pester is missing, ask the user before running `Install-Module Pester -MinimumVersion 5.5 -Scope CurrentUser`.
- [ ] Version the harness itself if not already: `git init; git add -A; git commit -m "harness MVP"` (local only; never add a remote).
- [ ] Run `Invoke-Pester ./tests -Output Detailed`.
- [ ] Run `./harness.ps1 testbed init -Force; ./harness.ps1 up; ./harness.ps1 status; ./harness.ps1 doctor`.

**Done when:** all Pester tests pass on Windows, `doctor` says healthy, `git status` in the harness root is clean.
**If tests fail on Windows only:** suspect line endings (CRLF in patches or seeds), path separators, or the hook shims (Git for Windows `sh` + `pwsh` on PATH). Fix in `scripts/lib/*`, add a regression test, rerun.

## Step 2: Phase 0 discovery  [user → agent]

- [ ] **[user]** Ask for the paths to the user's current app and API working copies, and whether they're on a branch with their usual local edits applied (or kept in stashes).
- [ ] Run `/discover app <path>` and `/discover api <path>` (or `./harness.ps1 discover <repo> -Path <path> -Out docs/discovery/<repo>.md`).
- [ ] Review each report. For every local edit, confirm or challenge the suggested tier, and flag anything that looks like feature work rather than env config.
- [ ] Answer the concept doc's open questions from the reports: default branch, root `Directory.Build.props` in the API, `launchSettings.json` tracked, husky in use, `UserSecretsId` present.
- [ ] Summarize for the user: (a) risks by severity, (b) final per-edit tier table, (c) Tier 4 list (should be short), (d) Phase 10 upstream-PR candidates.

**Done when:** the user has agreed the tier table. Reports are in `docs/discovery/` (gitignored, may contain local paths).

## Step 3: Cut over `harness.json` to AzDO  [agent+user]

- [ ] **[user]** Get the AzDO clone URLs for both repos, and confirm the default branch names found in Step 2.
- [ ] **[user]** Get the real `checkCommand` per repo. Proposed defaults: app `npm ci; npx ng build`, api `dotnet build; dotnet test --no-build`.
- [ ] Edit `harness.json`: `remotes.azdo`, `defaultBranch`, `checkCommand`, `userSecrets.project` (or remove it if the API has no `UserSecretsId`), then set `"mode": "azdo"`.
- [ ] Retire the testbed example patches: `./harness.ps1 patch retire app local-dev-server`, `./harness.ps1 patch retire api local-launch-profile`. Run `patch reset` first if they're applied.
- [ ] Review the example overlay files (`overlay/*/`) with the user. Keep, edit, or delete.
- [ ] `Remove-Item -Recurse -Force repos; ./harness.ps1 sync` (AzDO auth via Git Credential Manager; the user may need to sign in).
- [ ] `./harness.ps1 doctor`. If the app uses husky, confirm hooks are in `[takeover]` mode.

**Done when:** both clones come from AzDO, `doctor` is healthy, `git status` is clean in both clones.

## Step 4: Rebuild the local env from the tier table  [agent+user]

Do these in tier order. Lowest tier wins.

- [ ] **Tier 1:** port/proxy/env needs go into `aspen.code-workspace` task/launch `env` and `config/proxy.conf.json`. For secrets, the user copies `config/api.secrets.example.json` to `config/api.secrets.local.json` and fills it in themselves, then `./harness.ps1 secrets apply api`.
- [ ] **Tier 2:** only if Step 2 showed nothing blocking inheritance. Verify with `dotnet msbuild <proj> -preprocess:pp.xml` and search for `AspenHarness`.
- [ ] **Tier 3:** new local-only files go in `overlay/<repo>/...`, then `./harness.ps1 overlay apply`.
- [ ] **Tier 4:** for each remaining edit, make it in `repos/<repo>`, show the user the diff, then `/patch-capture <repo> <name> <file> <reason>` with a real `-RetireWhen`.
- [ ] After `npm ci` in the app, run `./harness.ps1 doctor`. husky's `prepare` may have reset `core.hooksPath`; re-take with `./harness.ps1 hooks install app`.

**Done when:** `./harness.ps1 up` from a fresh `repos/` reproduces the user's working env with no hand edits, `patch status` shows no drift, and `doctor` is healthy.

## Step 5: Run & debug on the real stack (Phase 3)  [agent+user]

- [ ] Run the `api: watch` and `app: serve` tasks individually, then `aspen: full stack`. Fix `aspen.code-workspace` paths, profile names, ports, and the `program` DLL path / target framework for the real solution.
- [ ] Confirm the app reaches the API through the proxy (`/api/...` → API port).
- [ ] **[user]** F5 `Aspen: Full Stack`: breakpoints hit in both C# and TypeScript.
- [ ] Verify `.vscode/mcp.json`: confirm current package names/URLs against official docs. Remove servers the user doesn't want. Don't add credentials to the file.
- [ ] Phase 0 leftover: check whether Copilot Chat picks up the harness-level `.github/copilot-instructions.md` in the multi-root workspace, or only the overlay-delivered per-repo copies. Record the result in the concept doc's open questions.

**Done when:** one F5 debugs both, and `git status` is clean in both clones apart from managed patch targets.

## Step 6: First real feature through the harness (Phase 9 exit)  [user approval required]

- [ ] **[user]** Pick a trivial, real change (typo fix, comment, small refactor), or agree on a throwaway branch.
- [ ] `/new-feature <repo> <name>`, then make the change.
- [ ] `./harness.ps1 clean-check <repo>`. It must pass.
- [ ] `/ship <repo> "<message>"`. Show the file list and wait for explicit approval before pushing.
- [ ] In AzDO, the branch diff should contain only the feature change. Have the user confirm.

**Done when:** a pushed branch contains feature changes only. The manual VS Pro + VS Code ritual can be retired.

## Step 7: Upstream local-override PR (Phase 10)  [agent drafts, user owns]

- [ ] Draft a short proposal (not code yet) for the team: a gitignored `*.local.*` convention covering the Tier 4 items from Step 4, e.g. `proxy.conf.local.json`, an `appsettings.Local.json` load, a `local` Angular configuration, a local launch profile. Use the patches' `reason` / `retireWhen` fields as the evidence.
- [ ] **[user]** The user decides whether and when to raise it with the team. The agent doesn't open PRs or post anywhere on its own.
- [ ] After merge: move each covered patch to Tier 1/3, `patch retire` it, and confirm `up` still reproduces the env.

**Done when:** the Tier 4 count is at its irreducible minimum (target 0).

## Ongoing maintenance (each work session)

- `./harness.ps1 sync`, then `./harness.ps1 status`. Act on drift with `/patch-refresh`.
- After any `npm ci` / `npm install` in the app: `./harness.ps1 doctor`.
- Patch drift warning on a file you didn't expect to change upstream: read the upstream diff before refreshing, since it may make the patch obsolete.
- New local need: Tier 1 → 4 in that order. Never leave an uncaptured edit in a clone.

---

## Log
<!-- yyyy-mm-dd: step N: outcome -->
