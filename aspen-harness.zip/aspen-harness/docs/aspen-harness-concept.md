# Aspen Local Harness — Concept

## Original Problem

Aspen = enterprise app: Angular web app + .NET API, each in its own AzDO repo, owned by the team.

Current local dev loop:
- Open VS Code (app) + Visual Studio Pro (API)
- Pull latest in each
- Hand-edit configs (`package.json`, `angular.json`, `launchSettings.json`, appsettings, etc.) to make things run locally / fit the situation
- Must not commit/push those edits

Want: a personal, local-only workspace wrapping both repos so custom dev env (agents, run behaviors, scripts, local configs) lives outside their codebases. Feature work should still be: pull → branch → spin up env → build feature → push branch containing only the feature.

Open question was: with three git-controlled things (app, API, parent), what is the right structure?

## Goals

- Zero footprint on upstream repos (no committed local config, no workflow assumptions imposed on team)
- One command / one window to sync, configure, run, debug both
- Personal tooling versioned in its own (local) repo
- Feature branches pushed upstream contain only feature changes — enforced, not remembered
- Agent config (Copilot, Claude Code, MCP) centralized across both repos

## Non-Goals

- Pushing the harness anywhere / sharing it with the team
- Replacing team build/CI
- Pinning upstream versions (always track latest)

## Decision: Harness Repo + Nested Independent Clones

Not submodules [high]. Submodules pin commits in the parent; harness never pushes and always wants latest, so pinning adds detached-HEAD friction for no benefit.

```
aspen-harness/                 git repo #3, local only
  aspen.code-workspace         multi-root workspace; tasks + launch compounds
  .gitignore                   /repos/
  repos/
    app/                       plain AzDO clone (real repo, edited directly)
    api/                       plain AzDO clone
  overlay/app/, overlay/api/   local-only new files copied into clones
  patches/app/, patches/api/   edits to tracked upstream files + manifest
  hooks/                       guard hook sources, installed into repos/*/.git/hooks
  scripts/                     sync, apply/reset, new-feature, ship, doctor
  AGENTS.md, CLAUDE.md, .github/, .vscode/mcp.json
```

Key properties:
- Parent ignores `repos/` → three histories never mix
- `repos/app` and `repos/api` are the real clones; feature code is written there directly. No copying between harness and repos.
- VS Code SCM panel shows each repo separately; commit/push per repo from one window (or `git -C repos/app push`)

## Local Change Tiers

Use the lowest tier that works.

| Tier | Mechanism | Use for | Confidence |
|---|---|---|---|
| 1 | Built-in overrides: `appsettings.Development.json`, user-secrets, `ASPNETCORE_*`/`DOTNET_*` env vars in launch configs, `ng serve --proxy-config <harness file>` | Connection strings, ports, URLs, proxying | high |
| 2 | Parent-dir inheritance: `Directory.Build.props/.targets`, `.editorconfig`, `nuget.config` in harness root | Build props, analyzers, feeds | high (props blocked if API repo has own root `Directory.Build.props` that doesn't import upward; `.editorconfig` ignored if repo's has `root=true`). **Correction:** npm does not read parent-dir `.npmrc`; use `~/.npmrc` or `NPM_CONFIG_*` env vars (Tier 1). |
| 3 | Overlay files + `.git/info/exclude` | New untracked local files (local proxy conf, scripts, instructions) | high |
| 4 | Patch framework | Unavoidable edits to tracked files (`angular.json`, `launchSettings.json`, `package.json` scripts) | medium-high; main maintenance cost |

Avoid `git update-index --skip-worktree` / `--assume-unchanged`: breaks on pull conflicts, hides drift silently.

## Guardrails (summary)

- `pre-commit` hook in each clone (`.git/hooks/` is local, unversioned → safe): rejects staged changes to patch-managed or overlay paths
- `pre-push` hook: re-checks the outgoing commit range
- Patch apply is all-or-nothing; any rejected hunk fails loudly
- Drift detection: patch manifest records upstream blob hash of each target file; changes flagged on sync
- `doctor` command verifies hooks installed/current, patch state consistent, excludes present
- Pre-PR check: build/run feature branch once with overlay + patches removed

## Feature Workflow

1. `new-feature app <name>` → fetch, branch from `origin/main`, apply overlay + patches
2. Write code in `repos/app`
3. `ship app` → reset patches, verify clean, commit/push (hooks backstop)
4. Re-apply local env, continue

Alternative [medium]: keep overlay applied, stage only feature paths (`git add -p`); hooks catch slips. Faster, riskier.

## Agents

- Claude Code / CLI agents run from harness root → see both repos + harness instructions
- Copilot Chat multi-root reads per-folder `.github/copilot-instructions.md` (inside upstream repos). Unverified whether harness-level instructions are picked up in multi-root. If not → deliver instruction file via Tier 3 overlay + exclude. [medium]
- MCP config: `.vscode/mcp.json` at harness / workspace level

## Run / Debug

- Tasks + launch configs live in `aspen.code-workspace`: `dotnet watch` + `ng serve`, compound debug launching both
- C# Dev Kit may remove need for Visual Studio Pro daily; keep VS Pro if solution depends on VS-only tooling [medium]

## Risks

| Risk | Mitigation |
|---|---|
| Patch rot when upstream changes targets | Fail-loud apply, blob-hash drift warning, `patch refresh` workflow |
| Env drift → "works only in my harness" | Pre-PR clean-env build/run |
| Accidental commit of local edits | pre-commit + pre-push hooks, `doctor` |
| Overbuilding | Build tiers 1–3 first; patches only for proven need |
| Hooks missing after re-clone | `sync` installs hooks every run; `doctor` verifies content |
| Repo uses husky / `core.hooksPath` | Local takeover: clone's local `core.hooksPath` → `.git/harness/hooks`, shims chain to husky; `npm install` resetting it is detected (doctor FAIL) and re-taken by `sync` |

## Strategic Recommendation

Tier 4 exists because upstream lacks local extension points. Propose a small team PR adding a gitignored local-override convention (`proxy.conf.local.json`, `appsettings.Local.json`, a `local` Angular configuration). Benefits team, retires most patches. [high]

## Open Questions

- Script language: PowerShell 7 assumed (Windows/enterprise). Confirm.
- Does the API repo have a root `Directory.Build.props`?
- Is `launchSettings.json` tracked in the API repo?
- Exact list of edits made today (drives patch inventory)
- Copilot multi-root instruction behavior (verify)
- Default branch name (`main` vs `develop`) per repo
