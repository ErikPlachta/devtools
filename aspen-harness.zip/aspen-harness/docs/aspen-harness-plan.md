# Aspen Local Harness — Development Plan

Ref: `aspen-harness-concept.md`. Assumes PowerShell 7 scripts, Windows, VS Code multi-root.

Each phase: deliverables + exit criteria. Do not advance until exit criteria pass.

---

## Phase 0 — Discovery

Deliverables:
- Inventory of every local edit made today, per file, per repo → classify each into Tier 1–4
- Answers: root `Directory.Build.props` in API? `launchSettings.json` tracked? default branches? Node/.NET/Angular CLI versions
- Copilot multi-root instruction test (harness-level vs per-folder)

Exit: every current local edit has an assigned tier; Tier 4 list is minimal and justified.

---

## Phase 1 — Mock Test Bed

Build harness against fake repos before touching real ones.

Deliverables:
- `testbed/` script creating two local bare remotes (`remote-app.git`, `remote-api.git`) seeded with minimal Angular-shaped and .NET-shaped files (`angular.json`, `package.json`, `launchSettings.json`, `appsettings.json`, `.csproj`)
- Script to simulate upstream commits (including ones touching patch targets) for drift/conflict tests
- Harness config flag to point remotes at testbed vs AzDO

Exit: harness can be fully exercised end-to-end with no network and no real code.

---

## Phase 2 — Skeleton

Deliverables:
- `aspen-harness/` git init, `.gitignore` (`/repos/`, state files)
- `harness.json`: repo names, remote URLs, default branches, paths
- `scripts/sync.ps1`: clone if missing, else fetch; never auto-merge dirty trees
- `aspen.code-workspace` with folders: harness root, `repos/app`, `repos/api`
- `README.md` for harness

Exit: fresh machine → `sync` → both clones present; SCM shows 3 repos; parent `git status` clean.

---

## Phase 3 — Run & Debug

Deliverables:
- Workspace `tasks`: `api:watch` (`dotnet watch`), `app:serve` (`ng serve --proxy-config ../../overlay-config/proxy.conf.json`), `restore`, `build`
- Workspace `launch`: API debug (C# Dev Kit), Chrome/Edge debug for app, compound `Aspen: Full Stack`
- Env vars for API injected via launch config (Tier 1)

Exit: one F5 starts and debugs both; no file in either clone modified.

---

## Phase 4 — Tier 1–2 Overrides

Deliverables:
- Harness-root `Directory.Build.props` / `.editorconfig` / `nuget.config` as needed (`.npmrc` is NOT inherited by npm: use `~/.npmrc` / `NPM_CONFIG_*`)
- User-secrets setup script for API
- Verify inheritance actually applies (`dotnet msbuild -preprocess`, config dumps)

Exit: all Tier 1–2 items from Phase 0 working; `git status` clean in both clones.

---

## Phase 5 — Tier 3 Overlay

Deliverables:
- `overlay/<repo>/` mirrored tree
- `scripts/overlay.ps1 apply|remove|status <repo>`:
  - copies files, records them in `.git/harness/overlay.lst`
  - maintains a fenced block in `.git/info/exclude` (`# >>> harness` / `# <<< harness`), rewritten idempotently
  - refuses to overwrite a tracked upstream file (that's Tier 4)
  - `remove` deletes only files it placed, and only if unmodified (or warns)

Exit: apply/remove round-trip leaves clone byte-identical; overlay files invisible to `git status`.

---

## Phase 6 — Tier 4 Patch Framework

### Structure
```
patches/<repo>/
  manifest.json
  001-angular-local-config.patch
  002-launch-profile.patch
```

`manifest.json` per patch:
- `name`, `file(s)` targeted, `reason`, `baseBlob` (upstream blob hash of each target at creation), `created`, `retireWhen` (e.g., "upstream local-override PR merged")

State: `repos/<repo>/.git/harness/patches.state` → applied patches + post-apply blob hashes.

### Commands (`scripts/patch.ps1`)
- `apply <repo>`: `git apply --check` every patch first; any failure → abort, apply nothing, print failing patch + hunk. Then apply all, write state.
- `reset <repo>`: reverse in reverse order (`git apply -R`); if a target was modified beyond the patch, stop and report (never discard user work).
- `status <repo>`: applied / not applied / drifted (current upstream blob ≠ `baseBlob`) / dirty-beyond-patch.
- `new <repo> <name> <file...>`: from current working-tree diff of named files → patch + manifest entry + `baseBlob`.
- `refresh <repo> <name>`: reset target to `origin/<default>`, `git apply --3way`, user resolves, regenerate patch, update `baseBlob`.
- `retire <repo> <name>`: remove patch + entry.

### Guardrails
- **pre-commit** (installed into `repos/<repo>/.git/hooks/`):
  - reject if any staged path ∈ manifest targets or overlay list
  - bypass only via explicit `HARNESS_ALLOW_PATCHED=1` for legit upstream edits to those files; logs bypass to `.git/harness/bypass.log`
- **pre-push**:
  - for `remote..local` range, reject if any commit touches manifest targets without a bypass log entry matching the commit
  - reject if patches currently applied AND branch has uncommitted target changes (sanity)
- **post-merge / post-checkout**: run `patch status`; warn on drift
- **Hook installer** in `sync`: writes hooks with version header + content hash; chains to any pre-existing hook rather than clobbering it
- **doctor**: hooks present + hash match, state file consistent with working tree, exclude block present, no orphan overlay files

### Tests (Pester, against Phase 1 test bed)
- apply/reset round-trip byte-identical
- partial-failure → nothing applied
- upstream change to target → drift flagged, apply fails loudly, refresh fixes
- commit of patched file blocked; bypass works and logs
- push of range containing patched file blocked
- hook chaining preserves existing hook

Exit: all tests green on test bed; Phase 0 Tier 4 items converted to patches.

---

## Phase 7 — Workflow Commands

Deliverables (`scripts/` or single `harness.ps1` entry with subcommands):
- `new-feature <repo> <name>`: dirty check → fetch → branch from `origin/<default>` → overlay apply → patch apply → open workspace
- `ship <repo>`: patch reset → overlay remove (optional flag) → show staged diff → commit (user message) → push → re-apply local env
- `clean-check <repo>`: env removed, restore + build (+ tests if fast) → confirms feature works without harness
- `up`: sync both, apply env, start full stack
- `status`: one-screen view: branch, ahead/behind, patch state, overlay state, hooks

Exit: full feature loop on test bed in ≤3 commands; clean-check catches a deliberately harness-dependent change.

---

## Phase 8 — Agent Layer

Deliverables:
- Harness `AGENTS.md` / `CLAUDE.md`: repo map, run commands, the tier rules, "never edit patch targets directly — use `patch new`"
- Copilot instructions: harness-level if Phase 0 test passed, else overlay-delivered `.github/copilot-instructions.md` (excluded)
- `.vscode/mcp.json` with relevant servers
- Optional: harness skills/prompts for `new-feature`, `ship`, `patch refresh`

Exit: agent started at harness root can explain layout, run stack, and refuses to commit patch targets.

---

## Phase 9 — Real Repo Cutover

Deliverables:
- Point `harness.json` at AzDO
- Run full loop on a trivial real branch (no PR, or throwaway PR)
- Retire manual VS Pro/VS Code ritual

Exit: one real feature shipped via harness; upstream diff contains feature only.

---

## Phase 10 — Upstream Local-Override PR

Deliverables:
- Team PR: gitignored `*.local.*` convention (`proxy.conf.local.json`, `appsettings.Local.json`, `local` Angular configuration, local launch profile)
- After merge: migrate matching patches to Tier 1/3; `patch retire`

Exit: Tier 4 count reduced to irreducible minimum (target: 0).

---

## Sequencing Notes

- Phases 1–2 together; mock is the build target per agreement
- Phase 6 is the largest; build `apply/reset/status` + pre-commit first, then pre-push, drift, refresh
- Phase 10 can start (proposal) any time after Phase 0
