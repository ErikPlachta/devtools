# Copilot instructions — Aspen harness

Follow the rules in `AGENTS.md` at the harness root.

Key points:
- `repos/app` (Angular) and `repos/api` (.NET) are real upstream clones. Write feature code there.
- Never stage or commit patch targets or overlay files in those clones; the git hooks will block it.
- Local-environment changes belong in the harness (tasks/env vars, overlay files, or `./harness.ps1 patch new`), never as uncommitted edits left in a clone.
- Before proposing a PR, run `./harness.ps1 clean-check <repo>`.

Note: in a multi-root workspace Copilot may read per-folder `.github/copilot-instructions.md` from the clones instead of this file. The harness delivers those via `overlay/<repo>/.github/copilot-instructions.md` (Phase 0: verify which is picked up).
