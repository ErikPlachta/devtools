# Entry point for the git hook shims in repos/<repo>/.git/hooks.
# Exit code is the hook result (non-zero blocks pre-commit / pre-push).
param(
    [string]$Hook,
    [string]$Repo,
    [Parameter(ValueFromRemainingArguments)][string[]]$HookArgs
)
$ErrorActionPreference = 'Stop'
try {
    Import-Module (Join-Path $PSScriptRoot '..' 'scripts' 'Harness.psm1') -Force -DisableNameChecking
    $stdin = @()
    if ([Console]::IsInputRedirected) {
        $stdin = @([Console]::In.ReadToEnd() -split "`r?`n" | Where-Object { $_.Trim() })
    }
    exit (Invoke-HarnessGuard -Hook $Hook -Repo $Repo -HookArgs @($HookArgs) -StdinLines $stdin)
}
catch {
    [Console]::Error.WriteLine("aspen-harness guard error ($Hook): $($_.Exception.Message)")
    # Fail closed for pre-* hooks, open for post-* hooks.
    if ($Hook -like 'pre-*') { exit 1 } else { exit 0 }
}
