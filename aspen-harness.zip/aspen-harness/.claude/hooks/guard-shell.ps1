# Claude Code PreToolUse hook (Bash|PowerShell). Permission rules can't see env-var prefixes
# (deny rules match past leading assignments), so guardrail bypasses are caught here and
# escalated to an explicit user prompt ("ask"). Exit 0 with no output = normal flow.
$ErrorActionPreference = 'Stop'
try {
    $payload = [Console]::In.ReadToEnd() | ConvertFrom-Json
    $cmd = [string]$payload.tool_input.command
}
catch { exit 0 }

$checks = @(
    @{ Pattern = 'HARNESS_ALLOW_PATCHED'; Reason = 'bypasses the harness pre-commit guard for patched/overlay files' }
    @{ Pattern = 'core\.hooksPath';       Reason = 'changes which git hooks run (can disable harness guardrails)' }
    @{ Pattern = '\.git[\\/](hooks|harness)'; Reason = 'touches harness hook/state files inside a clone' }
    @{ Pattern = '(^|\s)rm\s.*\brepos\b|Remove-Item.*\brepos\b'; Reason = 'deletes clone directories (uncommitted work would be lost)' }
)
foreach ($c in $checks) {
    if ($cmd -match $c.Pattern) {
        @{
            hookSpecificOutput = @{
                hookEventName            = 'PreToolUse'
                permissionDecision       = 'ask'
                permissionDecisionReason = "aspen-harness: this command $($c.Reason). Needs explicit user approval."
            }
        } | ConvertTo-Json -Depth 4 -Compress
        exit 0
    }
}
exit 0
