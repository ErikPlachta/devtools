---
description: Rebase a drifted or failing harness patch onto current upstream
argument-hint: <app|api> <patch-name>
---
Refresh a harness patch.

Arguments: $ARGUMENTS

1. Run `pwsh -NoProfile -File ./harness.ps1 patch status <repo>` and show the drift.
2. Run `pwsh -NoProfile -File ./harness.ps1 patch reset <repo>` (stop if it refuses; explain what's modified).
3. Run `pwsh -NoProfile -File ./harness.ps1 patch refresh <repo> <name>`.
4. If conflicts: show the conflicted hunks, explain upstream's change vs the local intent, propose a resolution, and wait for approval before editing. Then run the same command with `-Finish`.
5. Run `patch status` again and confirm no drift.
