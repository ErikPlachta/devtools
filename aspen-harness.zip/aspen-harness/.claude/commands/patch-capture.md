---
description: Capture a local edit to a tracked upstream file as a harness patch (Tier 4)
argument-hint: <app|api> <patch-name> <file> [reason]
---
Capture a local-only edit as a harness patch.

Arguments: $ARGUMENTS

1. Confirm the edit can't live in a lower tier: env var / CLI flag in `aspen.code-workspace` (Tier 1), harness-root `Directory.Build.props`/`nuget.config` (Tier 2), or a new untracked file in `overlay/<repo>/` (Tier 3). If it can, recommend that instead and stop.
2. Show `git -C repos/<repo> diff -- <file>` and confirm with the user that this diff is purely local-env.
3. Run `pwsh -NoProfile -File ./harness.ps1 patch new <repo> <name> <file> -Reason "<why>" -RetireWhen "<what upstream change would make this unnecessary>"`.
4. Run `pwsh -NoProfile -File ./harness.ps1 patch status <repo>` and report.
5. Add the item to the Phase 10 upstream-PR candidate list in your summary.
