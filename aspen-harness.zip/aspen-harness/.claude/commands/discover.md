---
description: Phase 0 discovery for an Aspen repo (risks + tier plan for current local edits)
argument-hint: <app|api> [path-to-existing-working-copy]
---
Run Phase 0 discovery.

Arguments: $ARGUMENTS

1. If a path is given, run `pwsh -NoProfile -File ./harness.ps1 discover <repo> -Path <path> -Out docs/discovery/<repo>.md`; otherwise scan the harness clone.
2. Read the report. For each local edit, confirm or challenge the suggested tier with reasoning; flag anything that looks like feature work rather than env config.
3. Produce: (a) risk list ordered by severity, (b) the Tier 4 list (should be short), (c) candidate items for the Phase 10 upstream local-override PR.
4. Do not change any files in the working copy being scanned.
