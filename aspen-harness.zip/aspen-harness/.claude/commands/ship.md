---
description: Commit and push the current feature branch with harness guardrails
argument-hint: <app|api> "<commit message>"
---
Ship feature work from an Aspen clone.

Arguments: $ARGUMENTS

1. Show `git -C repos/<repo> status --short` and `git -C repos/<repo> diff --stat`. Separate feature changes from anything that looks like local-env tweaking.
2. If any change is local-env (ports, URLs, connection strings, run scripts), do NOT ship it: propose the right tier (env var / overlay / `patch new`) instead.
3. Run `pwsh -NoProfile -File ./harness.ps1 clean-check <repo>`; if it fails, stop and report.
4. Show the exact file list that will be committed and the message. Wait for explicit approval ("yes, ship it").
5. Run `pwsh -NoProfile -File ./harness.ps1 ship <repo> -m "<message>"` (add `-All` only if the user approved committing everything shown).
6. Never use `--no-verify`, `HARNESS_ALLOW_PATCHED`, or force-push.
