---
description: Start a feature branch in an Aspen repo with the local env applied
argument-hint: <app|api> <feature-name>
---
Start a feature in the Aspen harness.

Arguments: $ARGUMENTS  (first = repo `app` or `api`, second = kebab-case feature name)

1. Run `pwsh -NoProfile -File ./harness.ps1 status` and report anything not clean in that repo. If the repo has non-harness uncommitted changes, stop and ask what to do with them.
2. Run `pwsh -NoProfile -File ./harness.ps1 new-feature <repo> <name>`.
3. Confirm the branch, that patches/overlay applied, and any drift warnings. If a patch failed to apply, explain and suggest `/patch-refresh`.
4. Do not start writing feature code until the user describes the feature.
