<!-- Delivered by aspen-harness overlay (Tier 3). Excluded via .git/info/exclude; never committed. -->
# Copilot instructions — aspen-web (local)

- Angular app. Run via the harness workspace task `app: serve`, not `npm start`.
- Do not edit `angular.json` serve options for local needs; those are managed by harness patches.
- API is proxied: `/api/*` -> `https://localhost:7101` (harness `config/proxy.conf.json`).
