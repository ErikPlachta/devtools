<!-- Delivered by aspen-harness overlay (Tier 3). Excluded via .git/info/exclude; never committed. -->
# Copilot instructions — aspen-api (local)

- .NET 8 minimal API. Run via harness task `api: watch` or launch config `.NET: Aspen API`.
- Local connection strings come from user-secrets / env vars (Tier 1). Never edit appsettings.json for local needs.
- `Properties/launchSettings.json` is harness-patched (port 7101). Do not commit it.
